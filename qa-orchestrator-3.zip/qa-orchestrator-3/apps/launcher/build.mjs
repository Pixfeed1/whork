// Bundle du launcher avant packaging.
//
// Pourquoi bundler : les paquets @qa/* sont des workspaces npm, hoistes a la
// racine du monorepo. electron-builder ne sait pas les embarquer proprement
// depuis un sous-dossier. En les inlinant avec esbuild, l'app packagee ne
// depend plus que de "gologin" et "electron-updater", installes normalement.

import * as esbuild from "esbuild";
import fs from "node:fs";
import path from "node:path";

const outdir = "dist";
fs.rmSync(outdir, { recursive: true, force: true });
fs.mkdirSync(outdir, { recursive: true });

const shared = {
  bundle: true,
  platform: "node",
  target: "node20",
  format: "cjs",
  sourcemap: true,
  minify: false,
  // Modules natifs / resolus a l'execution : jamais bundles.
  external: ["electron", "electron-updater", "gologin"],
  logLevel: "info",
};

// src/main.js est un module ESM (import.meta.url) mais la sortie est du CJS,
// ou import.meta n'existe pas. On le remappe sur l'equivalent CJS : sans ca,
// __dirname serait vide et le preload comme index.html seraient introuvables.
await esbuild.build({
  ...shared,
  entryPoints: ["src/main.js"],
  outfile: path.join(outdir, "main.cjs"),
  define: { "import.meta.url": "__esbuild_import_meta_url" },
  banner: {
    js: 'const __esbuild_import_meta_url = require("node:url").pathToFileURL(__filename).href;',
  },
});

await esbuild.build({
  ...shared,
  entryPoints: ["src/preload.cjs"],
  outfile: path.join(outdir, "preload.cjs"),
});

// Le renderer tourne dans une page sandboxee : simple copie.
for (const f of ["index.html", "renderer.js", "theme.js"]) {
  fs.copyFileSync(path.join("src", f), path.join(outdir, f));
}

console.log("Launcher bundle dans ./dist");
