import { app, BrowserWindow, ipcMain, shell } from "electron";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { JOB_HEARTBEAT_MS, versionSatisfies } from "@qa/shared";
import { getProviders } from "@qa/providers";
import { config } from "./config.js";
import * as store from "./store.js";
import * as api from "./api-client.js";
import { runJob, stopJob, activeJobIds } from "./runner.js";
import { registerProtocol, findDeepLink, parseDeepLink } from "./protocol.js";
import { setupUpdater, quitAndInstall } from "./updater.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

let win = null;
let token = null;
let identity = null; // { email, role, device }
let pollTimer = null;
let pendingDeepLink = null;
let versionPolicy = null;

// jobId -> { job, status, claimToken, hbTimer }
const jobs = new Map();

// --- Une seule instance : indispensable pour recevoir les deep links -------
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", (_e, argv) => {
    const link = findDeepLink(argv);
    if (link) handleDeepLink(link);
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
}

app.on("open-url", (event, url) => {
  event.preventDefault();
  handleDeepLink(url);
});

// --- Communication avec l'UI ----------------------------------------------

function send(channel, payload) {
  if (win && !win.isDestroyed()) win.webContents.send(channel, payload);
}
function logLine(level, message) {
  send("log", { t: new Date().toLocaleTimeString("fr-FR"), level, message });
}
function syncState() {
  send("state", {
    portalUrl: config.portalUrl,
    version: config.appVersion,
    identity,
    paired: Boolean(token),
    encryptionAvailable: store.encryptionAvailable(),
    polling: Boolean(pollTimer),
    versionPolicy,
    providerMode: getProviders().mode,
  });
  send(
    "jobs",
    [...jobs.values()].map((v) => ({
      id: v.job.id,
      url: v.job.targetUrl,
      region: v.job.region.key,
      status: v.status,
    })),
  );
}
function jobLogger(jobId) {
  return async (level, message) => {
    logLine(level, message);
    const entry = jobs.get(jobId);
    if (!token || !entry?.claimToken) return;
    try {
      await api.pushLog(token, jobId, entry.claimToken, level, message);
    } catch {
      // Un log perdu ne doit jamais interrompre un test en cours.
    }
  };
}

// --- Verification de version ----------------------------------------------

async function checkVersion(portalUrl) {
  versionPolicy = await api.fetchVersionPolicy(portalUrl);
  const ok = versionSatisfies(config.appVersion, versionPolicy.minVersion);
  versionPolicy.satisfied = ok;
  if (!ok) {
    logLine(
      "error",
      `Ce launcher (${config.appVersion}) est trop ancien : le portail exige ${versionPolicy.minVersion} minimum.`,
    );
  }
  syncState();
  return ok;
}

// --- Appairage -------------------------------------------------------------

async function handleDeepLink(url) {
  const parsed = parseDeepLink(url);
  if (!parsed || parsed.action !== "pair" || !parsed.code) return;
  if (!app.isReady()) {
    pendingDeepLink = url;
    return;
  }
  await doPair({ code: parsed.code, portalUrl: parsed.portal });
}

async function doPair({ code, portalUrl }) {
  try {
    const target = portalUrl || config.portalUrl;
    if (!target) throw new Error("Aucun portail indique dans le lien d'appairage.");
    store.setPortalUrl(target);

    if (!(await checkVersion(target))) {
      throw new Error("Mets a jour le launcher avant d'appairer ce poste.");
    }

    const r = await api.pair({
      code,
      deviceKey: store.deviceKey(),
      deviceName: os.hostname(),
      platform: `${process.platform} ${os.release()}`,
      appVersion: config.appVersion,
    });

    token = r.token;
    const { persisted } = store.setToken(r.token);
    identity = { email: r.email, role: r.role, device: r.device };

    logLine("info", `Poste appaire pour ${r.email}. Appareil « ${r.device.name} » : ${r.device.status}.`);
    if (!persisted) {
      logLine("warn", "Aucun coffre securise sur ce systeme : le token n'est pas conserve, l'appairage sera a refaire au prochain demarrage.");
    }
    if (r.device.status !== "APPROVED") {
      logLine("warn", "En attente d'approbation par un administrateur avant de pouvoir recuperer des jobs.");
    }
    syncState();
    return { ok: true, identity };
  } catch (e) {
    logLine("error", `Appairage refuse : ${e.message}`);
    syncState();
    return { ok: false, error: e.message };
  }
}

async function restoreIdentity() {
  const saved = store.getToken();
  if (!saved || !config.portalUrl) return;
  token = saved;
  try {
    await checkVersion(config.portalUrl);
    const me = await api.whoAmI(token);
    identity = { email: me.email, role: me.role, device: me.device };
    logLine("info", `Session retrouvee : ${me.email} · appareil ${me.device.status}.`);
  } catch (e) {
    if (e.status === 401) {
      store.clearToken();
      token = null;
      identity = null;
      logLine("warn", "Session expiree ou revoquee : ce poste doit etre reappaire.");
    } else {
      logLine("warn", `Portail injoignable : ${e.message}`);
    }
  }
  syncState();
}

// --- Heartbeat -------------------------------------------------------------

function startHeartbeat(jobId) {
  const entry = jobs.get(jobId);
  if (!entry || entry.hbTimer) return;
  entry.hbTimer = setInterval(async () => {
    const e = jobs.get(jobId);
    if (!e || e.status !== "RUNNING") return stopHeartbeat(jobId);
    try {
      await api.sendHeartbeat(token, jobId, e.claimToken);
    } catch (err) {
      logLine("warn", `Heartbeat refuse pour ce job : ${err.message}`);
      if (err.status === 409 || err.status === 403) stopHeartbeat(jobId);
    }
  }, JOB_HEARTBEAT_MS);
  entry.hbTimer.unref?.();
}

function stopHeartbeat(jobId) {
  const entry = jobs.get(jobId);
  if (entry?.hbTimer) {
    clearInterval(entry.hbTimer);
    entry.hbTimer = null;
  }
}

// --- Boucle de reclamation -------------------------------------------------

async function pollOnce() {
  if (!token || identity?.device?.status !== "APPROVED") return;
  try {
    const { job } = await api.claimNextJob(token);
    if (!job) return;

    jobs.set(job.id, { job, status: "RUNNING", claimToken: job.claimToken, hbTimer: null });
    startHeartbeat(job.id);
    syncState();

    const jlog = jobLogger(job.id);
    try {
      const { exitIp, proxyLabel } = await runJob(job, jlog);
      await api.reportStatus(token, job.id, job.claimToken, { status: "RUNNING", exitIp, proxyLabel });

      if (getProviders().isMock) {
        await stopJob(job, jlog);
        jobs.get(job.id).status = "DONE";
        stopHeartbeat(job.id);
        await api.reportStatus(token, job.id, job.claimToken, { status: "DONE" });
      }
    } catch (e) {
      const entry = jobs.get(job.id);
      if (entry) entry.status = "FAILED";
      stopHeartbeat(job.id);
      await jlog("error", e.message);
      await api.reportStatus(token, job.id, job.claimToken, { status: "FAILED", error: e.message }).catch(() => {});
    }
    syncState();
  } catch (e) {
    if (e.status === 426) {
      logLine("error", e.message);
      stopPolling();
    } else if (e.status === 401 || e.status === 403) {
      logLine("error", e.message);
      stopPolling();
    } else {
      logLine("error", e.message);
    }
    syncState();
  }
}

function stopPolling() {
  if (pollTimer) clearInterval(pollTimer);
  pollTimer = null;
  syncState();
}

// --- IPC -------------------------------------------------------------------

ipcMain.handle("get-state", async () => {
  syncState();
  return { ok: true };
});

ipcMain.handle("pair", async (_e, { code, portalUrl }) => doPair({ code, portalUrl }));

ipcMain.handle("unpair", async () => {
  stopPolling();
  store.clearToken();
  token = null;
  identity = null;
  logLine("info", "Poste desappaire. Le token local a ete efface.");
  syncState();
  return { ok: true };
});

ipcMain.handle("refresh-identity", async () => {
  await restoreIdentity();
  return { ok: true };
});

ipcMain.handle("start-polling", async () => {
  if (pollTimer) return { polling: true };
  if (!token) return { polling: false, error: "Poste non appaire." };
  if (identity?.device?.status !== "APPROVED") {
    return { polling: false, error: "Appareil en attente d'approbation." };
  }
  if (versionPolicy && !versionPolicy.satisfied) {
    return { polling: false, error: "Version du launcher trop ancienne." };
  }
  logLine("info", "Ecoute des jobs demarree.");
  pollTimer = setInterval(pollOnce, config.pollMs);
  pollTimer.unref?.();
  pollOnce();
  syncState();
  return { polling: true };
});

ipcMain.handle("stop-polling", async () => {
  logLine("info", "Ecoute des jobs arretee.");
  stopPolling();
  return { polling: false };
});

ipcMain.handle("stop-job", async (_e, { id }) => {
  const entry = jobs.get(id);
  if (!entry) return { ok: false };
  const jlog = jobLogger(id);
  await stopJob(entry.job, jlog);
  entry.status = "DONE";
  stopHeartbeat(id);
  await api.reportStatus(token, id, entry.claimToken, { status: "DONE" }).catch(() => {});
  syncState();
  return { ok: true };
});

ipcMain.handle("install-update", async () => {
  quitAndInstall();
  return { ok: true };
});

ipcMain.handle("open-portal", async () => {
  if (config.portalUrl) await shell.openExternal(config.portalUrl);
  return { ok: true };
});

// --- Cycle de vie ----------------------------------------------------------

function createWindow() {
  win = new BrowserWindow({
    width: 780,
    height: 700,
    backgroundColor: "#0a0f16",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
    title: "QA Launcher",
  });
  win.removeMenu?.();
  win.loadFile(path.join(__dirname, "index.html"));
  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: "deny" };
  });
  win.webContents.on("did-finish-load", () => syncState());
}

app.whenReady().then(async () => {
  registerProtocol();
  createWindow();

  await restoreIdentity();
  if (config.portalUrl && versionPolicy?.updateFeedUrl) {
    await setupUpdater({ feedUrl: versionPolicy.updateFeedUrl, log: logLine });
  }

  const link = pendingDeepLink || findDeepLink(process.argv);
  pendingDeepLink = null;
  if (link) await handleDeepLink(link);
});

// Ferme proprement les profils ouverts : ne jamais laisser un profil GoLogin
// avec le proxy de test applique.
app.on("before-quit", async (e) => {
  const ids = activeJobIds();
  if (!ids.length) return;
  e.preventDefault();
  for (const id of ids) {
    const entry = jobs.get(id);
    if (entry) await stopJob(entry.job, jobLogger(id)).catch(() => {});
  }
  app.exit(0);
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
app.on("activate", () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
