// Execute un job : construit le proxy Oxylabs pour la region, sauvegarde le
// proxy deja en place sur le profil, applique le nouveau, ouvre Orbita sur
// l'URL autorisee, lit l'IP de sortie. Aucune action automatisee sur la page.
//
// A la fermeture, le proxy d'origine est restaure si le scenario l'exige :
// un profil de QA emprunte n'est pas rendu modifie.
import { getProviders, buildProxyForRegion } from "@qa/providers";
import { config } from "./config.js";

const active = new Map(); // jobId -> { gl, browser, previousProxy, restoreProxy }

export async function runJob(job, log) {
  const providers = getProviders();
  const { gologin, oxylabsAccount, isMock } = providers;

  if (!isMock && !config.gologinToken) {
    throw new Error("GOLOGIN_API_TOKEN manquant (mode live).");
  }

  const proxy = buildProxyForRegion(oxylabsAccount, job.region, {
    sessionId: job.id.slice(0, 8), // session stable le temps du test
    sessionMinutes: 30,
  });
  await log("info", `Proxy region ${job.region.key} -> ${proxy.label}`);

  // Sauvegarde du proxy d'origine AVANT de l'ecraser.
  let previousProxy = null;
  if (job.restoreProxy) {
    try {
      previousProxy = await gologin.getProfileProxy(config.gologinToken, job.gologinProfileId);
      await log(
        "info",
        previousProxy
          ? `Proxy d'origine memorise (${previousProxy.host}:${previousProxy.port}), il sera restaure.`
          : "Le profil n'avait pas de proxy : il sera rendu tel quel.",
      );
    } catch (e) {
      await log("warn", `Lecture du proxy d'origine impossible : ${e.message}. Restauration desactivee pour ce job.`);
    }
  }

  await gologin.setProfileProxy(config.gologinToken, job.gologinProfileId, proxy);
  await log("info", "Proxy applique au profil GoLogin.");

  let launched;
  try {
    launched = await gologin.launchProfile(config.gologinToken, job.gologinProfileId, {
      startUrl: job.targetUrl,
    });
  } catch (e) {
    // Le lancement a echoue : on ne laisse pas le profil avec le proxy de test.
    await restoreProxy({ gologin, job, previousProxy }, log);
    throw e;
  }

  const { gl, browser, exitIp } = launched;
  active.set(job.id, { gl, browser, previousProxy, restoreProxy: job.restoreProxy });
  await log("info", `Profil ouvert sur ${job.targetUrl}${exitIp ? ` · IP sortie ${exitIp}` : ""}`);

  return { exitIp, proxyLabel: proxy.label };
}

async function restoreProxy({ gologin, job, previousProxy }, log) {
  if (!job.restoreProxy) return;
  try {
    if (previousProxy) {
      await gologin.setProfileProxy(config.gologinToken, job.gologinProfileId, previousProxy);
      await log?.("info", "Proxy d'origine restaure sur le profil.");
    } else {
      await gologin.clearProfileProxy(config.gologinToken, job.gologinProfileId);
      await log?.("info", "Profil rendu sans proxy, comme avant le test.");
    }
  } catch (e) {
    await log?.("error", `Restauration du proxy impossible : ${e.message}. A verifier a la main.`);
  }
}

export async function stopJob(job, log) {
  const entry = active.get(job.id);
  if (!entry) return;
  const { gologin } = getProviders();
  await gologin.stopProfile(entry.gl, entry.browser);
  await restoreProxy({ gologin, job, previousProxy: entry.previousProxy }, log);
  active.delete(job.id);
  if (log) await log("info", "Profil ferme.");
}

export function activeJobIds() {
  return [...active.keys()];
}
