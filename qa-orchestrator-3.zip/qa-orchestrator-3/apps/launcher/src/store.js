// Etat local du launcher, dans le repertoire utilisateur de l'app.
//
// Le token d'appairage est chiffre au repos via Electron safeStorage, qui
// s'appuie sur le trousseau de l'OS (DPAPI sur Windows, Keychain sur macOS,
// libsecret sur Linux). Si aucun coffre n'est disponible, on REFUSE d'ecrire
// le token en clair : l'appairage sera simplement redemande au prochain
// demarrage. Un secret en clair sur disque ne vaut pas le confort gagne.

import { app, safeStorage } from "electron";
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const FILE = () => path.join(app.getPath("userData"), "launcher-state.json");

let cache = null;
let memoryToken = null; // repli quand le trousseau OS est indisponible

function read() {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(FILE(), "utf8"));
  } catch {
    cache = {};
  }
  return cache;
}

function write(state) {
  cache = state;
  const file = FILE();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(state, null, 2), { mode: 0o600 });
  try {
    fs.chmodSync(file, 0o600); // au cas ou le fichier existait deja
  } catch {}
}

/** Identifiant stable de ce poste. Genere une fois, conserve ensuite. */
export function deviceKey() {
  const s = read();
  if (!s.deviceKey) {
    s.deviceKey = crypto.randomUUID() + crypto.randomBytes(8).toString("hex");
    write(s);
  }
  return s.deviceKey;
}

export function getPortalUrl() {
  return read().portalUrl || null;
}

export function setPortalUrl(url) {
  const s = read();
  s.portalUrl = url;
  write(s);
}

export function encryptionAvailable() {
  try {
    return safeStorage.isEncryptionAvailable();
  } catch {
    return false;
  }
}

export function getToken() {
  if (memoryToken) return memoryToken;
  const s = read();
  if (!s.tokenEnc) return null;
  try {
    return safeStorage.decryptString(Buffer.from(s.tokenEnc, "base64"));
  } catch {
    return null; // coffre change (autre machine, autre session) : reappairage
  }
}

export function setToken(token) {
  memoryToken = token;
  const s = read();
  if (!encryptionAvailable()) {
    delete s.tokenEnc;
    write(s);
    return { persisted: false };
  }
  s.tokenEnc = safeStorage.encryptString(token).toString("base64");
  write(s);
  return { persisted: true };
}

export function clearToken() {
  memoryToken = null;
  const s = read();
  delete s.tokenEnc;
  write(s);
}
