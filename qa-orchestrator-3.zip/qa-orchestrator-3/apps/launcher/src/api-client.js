import { config } from "./config.js";

class HttpError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
  }
}

async function req(path, { method = "GET", token, body, claimToken } = {}) {
  if (!config.portalUrl) throw new Error("Portail inconnu : appaire d'abord ce poste.");
  const res = await fetch(config.portalUrl + path, {
    method,
    headers: {
      "Content-Type": "application/json",
      // Envoyee sur chaque appel : le portail peut refuser une version obsolete.
      "X-Launcher-Version": config.appVersion,
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...(claimToken ? { "X-Claim-Token": claimToken } : {}),
    },
    ...(body ? { body: JSON.stringify(body) } : {}),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new HttpError(data.error || `HTTP ${res.status}`, res.status);
  return data;
}

/** Consulte sans authentification, avant tout le reste. */
export async function fetchVersionPolicy(portalUrl) {
  const res = await fetch(`${portalUrl}/api/launcher/version`, { cache: "no-store" });
  if (!res.ok) throw new Error(`Portail injoignable (HTTP ${res.status}).`);
  return res.json();
}

export async function pair({ code, deviceKey, deviceName, platform, appVersion }) {
  return req("/api/launcher/pair", {
    method: "POST",
    body: { code, deviceKey, deviceName, platform, appVersion },
  });
}

export async function whoAmI(token) {
  return req("/api/launcher/me", { token });
}

export async function claimNextJob(token) {
  return req("/api/launch/next", { method: "POST", token });
}

export async function reportStatus(token, jobId, claimToken, payload) {
  return req(`/api/launch/${jobId}/status`, { method: "POST", token, claimToken, body: payload });
}

export async function pushLog(token, jobId, claimToken, level, message) {
  return req(`/api/launch/${jobId}/logs`, {
    method: "POST",
    token,
    claimToken,
    body: { level, message },
  });
}

export async function sendHeartbeat(token, jobId, claimToken) {
  return req(`/api/launch/${jobId}/heartbeat`, { method: "POST", token, claimToken });
}

export { HttpError };
