// Protocole personnalise "qa-launcher://" : le portail affiche un lien, un clic
// ouvre l'app et transmet le ticket d'appairage. Aucun copier-coller.
//
// Windows / Linux : l'URL arrive dans argv d'une seconde instance.
// macOS          : l'URL arrive via l'evenement "open-url".

import { app } from "electron";
import path from "node:path";
import { APP_PROTOCOL } from "@qa/shared";

export { APP_PROTOCOL };

export function registerProtocol() {
  if (process.defaultApp) {
    // En dev (electron .), il faut pointer explicitement le script.
    if (process.argv.length >= 2) {
      app.setAsDefaultProtocolClient(APP_PROTOCOL, process.execPath, [path.resolve(process.argv[1])]);
    }
  } else {
    app.setAsDefaultProtocolClient(APP_PROTOCOL);
  }
}

/** Extrait le premier argument qui ressemble a un deep link. */
export function findDeepLink(argv = []) {
  return argv.find((a) => typeof a === "string" && a.startsWith(`${APP_PROTOCOL}://`)) || null;
}

/**
 * Analyse qa-launcher://pair?code=XXXX-XXXX&portal=https://qa.example.com
 * @returns {{ action:string, code:string|null, portal:string|null }|null}
 */
export function parseDeepLink(url) {
  try {
    const u = new URL(url);
    if (u.protocol !== `${APP_PROTOCOL}:`) return null;
    const action = (u.hostname || u.pathname.replace(/\//g, "")).toLowerCase();
    const portal = u.searchParams.get("portal");
    // On n'accepte que http/https comme portail : pas de file:// ni d'autre schema.
    let safePortal = null;
    if (portal) {
      const p = new URL(portal);
      if (p.protocol === "http:" || p.protocol === "https:") safePortal = p.origin;
    }
    return { action, code: u.searchParams.get("code"), portal: safePortal };
  } catch {
    return null;
  }
}
