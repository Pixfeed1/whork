// Thème du launcher — mêmes bornes que le portail : sombre de 19 h à 7 h.
//
// Chargé de façon BLOQUANTE dans <head> : la CSP interdit tout script inline
// (script-src 'self'), et un script en fin de body ferait clignoter la fenêtre.
//
// Ici, pas de sélecteur : la page tourne sur file://, où localStorage n'est pas
// fiable. La fenêtre suit l'heure, point. Le réglage manuel vit dans le portail.
(function () {
  var DARK_FROM = 19;
  var DARK_TO = 7;
  function apply() {
    var h = new Date().getHours();
    var t = h >= DARK_FROM || h < DARK_TO ? "dark" : "light";
    if (document.documentElement.dataset.theme !== t) {
      document.documentElement.dataset.theme = t;
    }
  }
  apply();
  setInterval(apply, 60000);
})();
