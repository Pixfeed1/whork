// Mise a jour automatique via electron-updater.
//
// electron-builder publie un latest.yml contenant le sha512 de chaque
// artefact ; electron-updater refuse une archive dont l'empreinte ne
// correspond pas. Sur Windows et macOS il verifie en plus la signature du
// binaire. C'est cette chaine qui rend la mise a jour sure — d'ou l'exigence
// de signer les builds (voir docs/PACKAGING.md).

let updater = null;

export async function setupUpdater({ feedUrl, log }) {
  if (!feedUrl) {
    log("info", "Aucun flux de mise a jour configure : mises a jour manuelles.");
    return null;
  }
  try {
    const mod = await import("electron-updater");
    updater = mod.autoUpdater || mod.default?.autoUpdater;
    updater.autoDownload = true;
    updater.autoInstallOnAppQuit = true;
    updater.setFeedURL({ provider: "generic", url: feedUrl });

    updater.on("update-available", (i) => log("info", `Mise a jour ${i.version} disponible, telechargement…`));
    updater.on("update-not-available", () => log("info", "Launcher a jour."));
    updater.on("error", (e) => log("warn", `Mise a jour impossible : ${e.message}`));
    updater.on("update-downloaded", (i) =>
      log("info", `Version ${i.version} prete : elle sera installee a la fermeture.`),
    );

    await updater.checkForUpdates();
    return updater;
  } catch (e) {
    log("warn", `Verification des mises a jour indisponible : ${e.message}`);
    return null;
  }
}

/** Installe maintenant (redemarre l'app). Appele depuis l'UI. */
export function quitAndInstall() {
  updater?.quitAndInstall();
}
