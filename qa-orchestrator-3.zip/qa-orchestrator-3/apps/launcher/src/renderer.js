const $ = (id) => document.getElementById(id);

// Tout passe par textContent : un message de log vient du serveur, il n'a rien
// a faire dans du innerHTML.
function addLog(line) {
  const el = $("log");
  const div = document.createElement("div");
  const t = document.createElement("span");
  t.className = "t";
  t.textContent = line.t;
  const lvl = document.createElement("span");
  lvl.className = line.level;
  lvl.textContent = ` ${line.level.toUpperCase()} `;
  div.append(t, lvl, document.createTextNode(line.message));
  el.appendChild(div);
  el.scrollTop = el.scrollHeight;
}

function banner(text, kind = "") {
  const b = $("banner");
  b.innerHTML = "";
  if (!text) return;
  const d = document.createElement("div");
  d.className = `notice ${kind}`;
  d.textContent = text;
  b.appendChild(d);
}

let state = null;

function render() {
  if (!state) return;
  const paired = state.paired && state.identity;
  $("pairPanel").classList.toggle("hidden", Boolean(paired));
  $("runPanel").classList.toggle("hidden", !paired);

  if (state.portalUrl && !$("portal").value) $("portal").value = state.portalUrl;

  if (paired) {
    $("who").textContent = `${state.identity.email} · ${state.identity.role}`;
    const d = state.identity.device;
    $("device").textContent = `Appareil « ${d.name} » · ${d.status} · providers : ${state.providerMode}`;
    const approved = d.status === "APPROVED";
    $("startBtn").disabled = !approved || state.polling || (state.versionPolicy && !state.versionPolicy.satisfied);
    $("startBtn").textContent = state.polling ? "Écoute active…" : "Démarrer l'écoute";
  }

  if (state.versionPolicy && state.versionPolicy.satisfied === false) {
    banner(
      `Ce launcher (${state.version}) est trop ancien. Le portail exige la version ${state.versionPolicy.minVersion} minimum. Mets-le à jour pour reprendre les tests.`,
      "bad",
    );
  } else if (paired && state.identity.device.status === "PENDING") {
    banner("Cet appareil attend l'approbation d'un administrateur. Les tests démarreront une fois approuvé.");
  } else if (paired && state.identity.device.status === "REVOKED") {
    banner("Cet appareil a été révoqué. Contacte un administrateur.", "bad");
  } else if (!state.encryptionAvailable) {
    banner("Aucun coffre-fort système détecté : le jeton ne sera pas conservé et l'appairage sera à refaire au prochain démarrage.");
  } else {
    banner("");
  }

  $("footer").textContent = `Version ${state.version}${state.portalUrl ? ` · portail ${state.portalUrl}` : ""}`;
}

window.qa.onLog(addLog);
window.qa.onState((s) => {
  state = s;
  render();
});

window.qa.onJobs((jobs) => {
  const box = $("jobs");
  box.innerHTML = "";
  jobs.forEach((j) => {
    const row = document.createElement("div");
    row.className = "job";

    const u = document.createElement("span");
    u.className = "u";
    const region = document.createElement("span");
    region.className = j.status;
    region.textContent = j.region;
    u.append(document.createTextNode(`${j.url} · `), region);

    row.appendChild(u);
    if (j.status === "RUNNING") {
      const b = document.createElement("button");
      b.className = "danger";
      b.textContent = "Terminer";
      b.onclick = () => window.qa.stopJob(j.id);
      row.appendChild(b);
    } else {
      const badge = document.createElement("span");
      badge.className = `badge ${j.status}`;
      badge.textContent = j.status;
      row.appendChild(badge);
    }
    box.appendChild(row);
  });
});

$("pairBtn").onclick = async () => {
  $("pairBtn").disabled = true;
  try {
    const r = await window.qa.pair({ code: $("code").value.trim(), portalUrl: $("portal").value.trim() });
    if (r.ok) $("code").value = "";
  } finally {
    $("pairBtn").disabled = false;
  }
};

$("startBtn").onclick = async () => {
  const r = await window.qa.startPolling();
  if (r.error) addLog({ t: new Date().toLocaleTimeString("fr-FR"), level: "error", message: r.error });
};

$("unpairBtn").onclick = () => window.qa.unpair();
$("portalBtn").onclick = () => window.qa.openPortal();

window.qa.getState();
