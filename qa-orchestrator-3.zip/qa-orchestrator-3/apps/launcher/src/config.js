// Config du launcher.
// L'URL du portail vient de l'appairage (deep link) et est memorisee ;
// les variables d'environnement restent prioritaires pour le developpement.

import { app } from "electron";
import { getPortalUrl } from "./store.js";

export const config = {
  get portalUrl() {
    return process.env.QA_PORTAL_URL || getPortalUrl() || "";
  },
  get appVersion() {
    return app.getVersion();
  },
  // Token GoLogin (mode live). En mock, inutile.
  gologinToken: process.env.GOLOGIN_API_TOKEN || "",
  pollMs: Number(process.env.QA_POLL_MS || 4000),
};
