const { contextBridge, ipcRenderer } = require("electron");

// Surface d'API minimale : le renderer ne touche ni au reseau, ni au disque,
// ni au token. Il demande, le main process decide.
contextBridge.exposeInMainWorld("qa", {
  getState: () => ipcRenderer.invoke("get-state"),
  pair: (payload) => ipcRenderer.invoke("pair", payload),
  unpair: () => ipcRenderer.invoke("unpair"),
  refreshIdentity: () => ipcRenderer.invoke("refresh-identity"),
  startPolling: () => ipcRenderer.invoke("start-polling"),
  stopPolling: () => ipcRenderer.invoke("stop-polling"),
  stopJob: (id) => ipcRenderer.invoke("stop-job", { id }),
  installUpdate: () => ipcRenderer.invoke("install-update"),
  openPortal: () => ipcRenderer.invoke("open-portal"),
  onLog: (cb) => ipcRenderer.on("log", (_e, line) => cb(line)),
  onJobs: (cb) => ipcRenderer.on("jobs", (_e, jobs) => cb(jobs)),
  onState: (cb) => ipcRenderer.on("state", (_e, state) => cb(state)),
});
