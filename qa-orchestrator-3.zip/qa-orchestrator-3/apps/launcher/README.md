# QA Launcher (Electron)

Client local qui execute les tests mis en file par le portail. Il ne recoit que
les jobs demandes par **son propre** utilisateur, sur un poste approuve.

## Comment un poste obtient l'acces

Il n'y a pas de formulaire email/mot de passe dans le launcher. Le seul chemin :

```
portail « Mon launcher » -> code a usage unique (10 min)
   -> qa-launcher://pair?code=...   (un clic)
      -> appareil enregistre, en attente
         -> approbation admin
            -> le launcher reclame les jobs de cet utilisateur
```

Le jeton obtenu est de nature `LAUNCHER` : il ne deverrouille pas l'interface
web. Inversement, un cookie web ne peut pas reclamer de job. Il est chiffre au
repos via `safeStorage` (DPAPI sur Windows, Keychain sur macOS, libsecret sur
Linux). Si aucun coffre n'est disponible, le jeton n'est pas ecrit sur disque :
l'appairage sera redemande au prochain demarrage.

## Developper

```bash
# depuis la racine du monorepo
npm install
QA_PORTAL_URL=http://localhost:3000 npm run launcher:dev
```

`launcher:dev` bundle avant de lancer : `src/` n'est jamais execute directement,
c'est `dist/main.cjs` qui tourne, en dev comme en production.

En mode `PROVIDER_MODE=mock` (defaut), ni GoLogin ni Oxylabs ne sont requis :
le launcher simule l'ouverture et remonte un resultat.

## Packager

Voir [docs/PACKAGING.md](../../docs/PACKAGING.md) : installeurs, signature,
notarisation, protocole, mise a jour automatique.

```bash
npm run launcher:dist:win     # NSIS
npm run launcher:dist:mac     # DMG signe + notarise
npm run launcher:dist:linux   # AppImage + deb
```

## Variables

| Variable            | Role                                                      |
|---------------------|-----------------------------------------------------------|
| `QA_PORTAL_URL`     | Surcharge de dev. En prod l'URL vient du lien d'appairage. |
| `PROVIDER_MODE`     | `mock` ou `live`                                          |
| `GOLOGIN_API_TOKEN` | Token GoLogin (mode live uniquement)                      |
| `OXYLABS_*`         | Identifiants proxy (mode live)                            |
| `QA_POLL_MS`        | Intervalle d'interrogation (defaut 4000 ms)               |

## Cycle d'un job

1. `POST /api/launch/next` — reclamation **atomique** (`FOR UPDATE SKIP
   LOCKED`), filtree sur l'utilisateur. Renvoie un `claimToken`, une seule fois.
2. Le proxy en place sur le profil est relu et memorise (si le scenario demande
   la restauration), puis le proxy Oxylabs de la region est applique.
3. Orbita s'ouvre sur l'URL demandee. Aucune action n'est automatisee sur la page.
4. Toutes les 30 s, `POST /api/launch/{id}/heartbeat` prolonge le bail. Sans
   heartbeat pendant 90 s, le portail fait echouer le job : plus de job fantome
   bloque en RUNNING.
5. A la fermeture (bouton, ou `before-quit`), le profil est ferme **et le proxy
   d'origine restaure**. Un profil emprunte est rendu tel qu'il etait.

Le `claimToken` accompagne chaque ecriture (logs, statut, heartbeat) dans
l'en-tete `X-Claim-Token`. Sans lui, l'API refuse : un autre launcher ne peut
ni polluer les logs, ni changer le statut d'un job qui ne lui appartient pas.

## Version minimale

Chaque appel porte `X-Launcher-Version`. Si le portail exige plus recent
(`LAUNCHER_MIN_VERSION`), l'API repond 426 et le launcher s'arrete avec un
bandeau explicite. La mise a jour se fait via electron-updater si un flux est
configure, sinon a la main.
