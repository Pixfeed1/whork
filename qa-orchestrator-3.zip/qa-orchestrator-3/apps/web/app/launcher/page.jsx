import { requireUser } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import PairPanel from "./PairPanel.jsx";

export const dynamic = "force-dynamic";

export default async function LauncherPage() {
  const user = await requireUser();
  const devices = await prisma.device.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    select: { id: true, name: true, platform: true, appVersion: true, status: true, lastSeenAt: true },
  });

  return (
    <div className="wrap">
      <p className="eyebrow">Mon launcher</p>
      <h1>Appairer un poste</h1>
      <p className="sub">
        Le launcher s'installe sur ton poste et n'accepte de jobs qu'apres appairage. Un code ne sert qu'une
        fois, sur un seul poste, et expire au bout de 10 minutes.
      </p>
      <PairPanel
        devices={devices.map((d) => ({ ...d, lastSeenAt: d.lastSeenAt?.toISOString() || null }))}
        isAdmin={user.role === "ADMIN"}
      />
    </div>
  );
}
