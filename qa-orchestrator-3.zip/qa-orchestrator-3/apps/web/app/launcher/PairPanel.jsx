"use client";
import { useState } from "react";

export default function PairPanel({ devices, isAdmin }) {
  const [ticket, setTicket] = useState(null);
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);

  async function issue() {
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch("/api/pairing/tickets", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur");
      setTicket(data.ticket);
    } catch (e) {
      setMsg(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <div className="panel" style={{ marginTop: 22 }}>
        <button className="btn primary" onClick={issue} disabled={busy}>
          {busy ? "Génération…" : "Générer un code d'appairage"}
        </button>
        {msg && <div className="err">{msg}</div>}

        {ticket && (
          <div style={{ marginTop: 18 }}>
            <label>Code à saisir dans le launcher</label>
            <div
              style={{
                fontFamily: "var(--mono)",
                fontSize: "clamp(17px, 5.2vw, 24px)",
                letterSpacing: "0.14em",
                color: "var(--accent)",
                padding: "12px 0",
                overflowWrap: "anywhere",
              }}
            >
              {ticket.code}
            </div>
            <a className="btn primary" href={ticket.deepLink} style={{ display: "inline-block" }}>
              Ouvrir le launcher et appairer
            </a>
            <p className="hint">
              Le bouton ouvre l'application installée sur ce poste et transmet le code.
              {!isAdmin && " Un administrateur devra ensuite approuver l'appareil."}
              <br />
              Valable jusqu'à {new Date(ticket.expiresAt).toLocaleTimeString("fr-FR")}. Un seul usage.
            </p>
          </div>
        )}
      </div>

      <h2 className="sec">Mes appareils</h2>
      {devices.length === 0 && (
        <div className="row">
          <span className="meta">Aucun poste appairé pour l'instant.</span>
        </div>
      )}
      {devices.map((d) => (
        <div className="row" key={d.id}>
          <div>
            <div className="name">{d.name}</div>
            <div className="meta">
              {d.platform || "plateforme inconnue"} · launcher {d.appVersion || "?"}
              {d.lastSeenAt ? ` · vu ${new Date(d.lastSeenAt).toLocaleString("fr-FR")}` : " · jamais connecté"}
            </div>
          </div>
          <span className="spacer" />
          <span className={`badge ${d.status === "APPROVED" ? "DONE" : d.status === "REVOKED" ? "FAILED" : "PENDING"}`}>
            {d.status === "APPROVED" ? "approuvé" : d.status === "REVOKED" ? "révoqué" : "en attente"}
          </span>
        </div>
      ))}
    </>
  );
}
