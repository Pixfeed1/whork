"use client";
import { useEffect, useState } from "react";

export default function LaunchPanel({ scenarios }) {
  const [scenarioId, setScenarioId] = useState(scenarios[0]?.id || "");
  const [url, setUrl] = useState("");
  const [msg, setMsg] = useState(null);
  const [busy, setBusy] = useState(false);
  const [jobs, setJobs] = useState([]);

  const scenario = scenarios.find((s) => s.id === scenarioId);
  // On complete le schema si l'utilisateur colle un hote nu.
  const target = url.trim() && !/^https?:\/\//i.test(url.trim()) ? `https://${url.trim()}` : url.trim();

  let host = null;
  try {
    host = target ? new URL(target).host : null;
  } catch {
    host = null;
  }

  async function refresh() {
    const res = await fetch("/api/launch");
    if (res.ok) setJobs((await res.json()).jobs || []);
  }
  useEffect(() => { refresh(); const t = setInterval(refresh, 4000); return () => clearInterval(t); }, []);

  async function launch() {
    setBusy(true); setMsg(null);
    try {
      const res = await fetch("/api/launch", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenarioId, targetUrl: target }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Refuse");
      setMsg({ ok: true, text: "Test mis en file. Le launcher va l'executer." });
      refresh();
    } catch (e) { setMsg({ ok: false, text: e.message }); } finally { setBusy(false); }
  }

  if (!scenarios.length) return <div className="notice">Aucun scenario actif. Demande a un admin d'en creer un.</div>;

  return (
    <>
      <div className="panel">
        <div className="grid two">
          <div>
            <label htmlFor="sc">Scenario</label>
            <select id="sc" value={scenarioId} onChange={(e) => { setScenarioId(e.target.value); setMsg(null); }}>
              {scenarios.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="pa">URL a ouvrir</label>
            <input
              id="pa"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://exemple.com/checkout"
              onKeyDown={(e) => { if (e.key === "Enter" && host && !busy) launch(); }}
            />
          </div>
        </div>
        {scenario && (
          <p className="hint">
            Profil <b>{scenario.profile}</b> · region <b>{scenario.region}</b>
            {host && <><br />Cible : <span style={{ color: "var(--accent)" }}>{target}</span></>}
          </p>
        )}
        {msg && <div className={msg.ok ? "ok" : "err"}>{msg.text}</div>}
        <div style={{ marginTop: 14 }}>
          <button className="btn primary" onClick={launch} disabled={busy || !scenarioId || !host}>{busy ? "Envoi…" : "Lancer le test"}</button>
        </div>
      </div>

      <h2 className="sec">Lancements recents</h2>
      <div>
        {jobs.length === 0 && <div className="row"><span className="meta">Aucun lancement pour l'instant.</span></div>}
        {jobs.map((j) => (
          <div className="row" key={j.id}>
            <div>
              <div className="name">{j.scenario?.name || "—"}</div>
              <div className="meta">{j.host} · {j.regionKey}{j.exitIp ? ` · sortie ${j.exitIp}` : ""}{j.error ? ` · ${j.error}` : ""}</div>
            </div>
            <span className="spacer" />
            <span className={`badge ${j.status}`}>{j.status}</span>
          </div>
        ))}
      </div>
    </>
  );
}
