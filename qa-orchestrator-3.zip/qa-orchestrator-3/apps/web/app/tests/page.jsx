import { prisma } from "@/lib/db.js";
import { requireUser } from "@/lib/auth.js";
import LaunchPanel from "./LaunchPanel.jsx";

export const dynamic = "force-dynamic";

export default async function TestsPage() {
  const user = await requireUser();
  // Un testeur ne voit que les scenarios dont le profil lui est attribue.
  const scenarios = await prisma.scenario.findMany({
    where: {
      active: true,
      ...(user.role === "ADMIN"
        ? {}
        : { testProfile: { assignments: { some: { userId: user.id } } } }),
    },
    include: { testProfile: true, region: true },
    orderBy: { name: "asc" },
  });
  const plain = scenarios.map((s) => ({
    id: s.id, name: s.name, description: s.description,
    profile: s.testProfile.name, region: s.region.label, regionKey: s.region.key,
  }));
  return (
    <div className="wrap">
      <p className="eyebrow">Espace testeur</p>
      <h1>Lancer un test</h1>
      <p className="sub">Choisis un scenario, saisis l'URL a ouvrir, puis lance. Le launcher local ouvre le profil GoLogin avec la region choisie.</p>
      <LaunchPanel scenarios={plain} />
    </div>
  );
}
