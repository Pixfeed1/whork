import "./globals.css";
import { getCurrentUser } from "@/lib/auth.js";
import LogoutButton from "./LogoutButton.jsx";
import ThemeToggle from "./ThemeToggle.jsx";
import { THEME_INIT } from "./theme.js";

export const metadata = {
  title: "QA Orchestrator",
  description: "Orchestrateur QA interne — profils GoLogin de test + regions Oxylabs.",
};

export default async function RootLayout({ children }) {
  const user = await getCurrentUser();
  return (
    <html lang="fr" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <script dangerouslySetInnerHTML={{ __html: THEME_INIT }} />
      </head>
      <body>
        {user && (
          <nav className="nav">
            <span className="brand">QA<span className="dot">·</span>Orchestrator</span>
            <span className="links">
              <a href="/tests">Tests</a>
              <a href="/launcher">Mon launcher</a>
              {user.role === "ADMIN" && <a href="/admin">Admin</a>}
            </span>
            <span className="spacer" />
            <ThemeToggle />
            <span className="tag">{user.role === "ADMIN" ? "admin" : "testeur"}</span>
            <span className="who">{user.email}</span>
            <LogoutButton />
          </nav>
        )}
        {children}
      </body>
    </html>
  );
}
