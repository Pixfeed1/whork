// Politique de thème, partagée entre le script inline et le sélecteur.
//
// Bascule automatique sur l'heure LOCALE du poste : sombre de 19 h à 7 h.
// Le choix des bornes : une console QA se regarde en journée de travail, et
// 19 h correspond à la tombée du jour sur une bonne partie de l'année en
// France sans être ridicule en été. 7 h évite d'éblouir celui qui ouvre
// l'outil au réveil.
//
// Trois états possibles, stockés dans localStorage sous "qa-theme" :
//   auto  (défaut) — l'heure décide, et re-décide toutes les minutes
//   light          — forcé clair
//   dark           — forcé sombre
// Un mode automatique sans échappatoire est hostile : quelqu'un dans une pièce
// sombre à 10 h doit pouvoir forcer. D'où le sélecteur dans la barre.

export const DARK_FROM = 19; // 19:00 -> sombre
export const DARK_TO = 7; //  07:00 -> clair
export const THEME_KEY = "qa-theme";

// Script injecté tel quel dans <head>, AVANT le premier rendu : sans lui, la
// page s'afficherait en sombre puis sauterait en clair (flash).
export const THEME_INIT = `(function(){
  var K=${JSON.stringify(THEME_KEY)},F=${DARK_FROM},T=${DARK_TO};
  function byTime(){var h=new Date().getHours();return (h>=F||h<T)?"dark":"light";}
  function mode(){try{return localStorage.getItem(K)||"auto";}catch(e){return "auto";}}
  function apply(){var m=mode();var t=(m==="light"||m==="dark")?m:byTime();
    var d=document.documentElement;
    if(d.dataset.theme!==t)d.dataset.theme=t;
    d.dataset.themeMode=m;}
  apply();
  setInterval(apply,60000);
  window.__qaApplyTheme=apply;
})();`;
