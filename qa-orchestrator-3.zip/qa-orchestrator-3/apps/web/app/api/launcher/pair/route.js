import { redeemPairingTicket } from "@/lib/pairing.js";
import { hit, clientIp } from "@/lib/rate-limit.js";

export const runtime = "nodejs";

// Seul point d'entree pour obtenir un token de launcher : un ticket a usage
// unique. Aucun mot de passe n'est accepte ici.
export async function POST(req) {
  const ip = clientIp(req);
  const limit = hit(`pair:${ip}`, 10, 10 * 60_000);
  if (!limit.ok) {
    return Response.json(
      { error: "Trop de tentatives d'appairage. Reessaie plus tard." },
      { status: 429, headers: { "Retry-After": String(limit.retryAfter) } },
    );
  }

  try {
    const { code, deviceKey, deviceName, platform, appVersion } = await req.json();
    if (!code || !deviceKey) {
      return Response.json({ error: "code et deviceKey requis." }, { status: 400 });
    }
    const r = await redeemPairingTicket({ code, deviceKey, deviceName, platform, appVersion, ip });
    return Response.json({
      token: r.token,
      expiresAt: r.expiresAt,
      email: r.user.email,
      role: r.user.role,
      device: { id: r.device.id, name: r.device.name, status: r.device.status },
    });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
