import { resolveSession } from "@/lib/auth.js";
import { SessionKind } from "@qa/shared";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Etat de l'appairage. Volontairement PAS derriere requireLauncher : un
// appareil en attente d'approbation doit pouvoir consulter son propre statut.
export async function GET(req) {
  const ctx = await resolveSession(req);
  if (!ctx || ctx.session.kind !== SessionKind.LAUNCHER || !ctx.device) {
    return Response.json({ error: "Token de launcher requis." }, { status: 401 });
  }
  return Response.json({
    email: ctx.user.email,
    role: ctx.user.role,
    device: {
      id: ctx.device.id,
      name: ctx.device.name,
      status: ctx.device.status,
      approvedAt: ctx.device.approvedAt,
    },
  });
}
