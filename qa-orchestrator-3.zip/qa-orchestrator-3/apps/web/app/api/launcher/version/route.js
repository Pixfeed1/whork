import { LAUNCHER_MIN_VERSION } from "@/lib/auth.js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Consulte par le launcher au demarrage, AVANT toute authentification.
// Permet de bloquer une version obsolete sans toucher au client deja deploye.
export async function GET() {
  return Response.json({
    minVersion: LAUNCHER_MIN_VERSION,
    latestVersion: process.env.LAUNCHER_LATEST_VERSION || LAUNCHER_MIN_VERSION,
    // Base des artefacts publies (latest.yml, .exe, .dmg, checksums).
    updateFeedUrl: process.env.LAUNCHER_UPDATE_FEED_URL || null,
    downloadPageUrl: process.env.LAUNCHER_DOWNLOAD_URL || null,
  });
}
