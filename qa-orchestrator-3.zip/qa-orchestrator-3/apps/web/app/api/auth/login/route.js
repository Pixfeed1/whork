import { prisma } from "@/lib/db.js";
import { verifyPassword, createSession } from "@/lib/auth.js";
import { loginSchema } from "@qa/validation";
import { hit, reset, clientIp } from "@/lib/rate-limit.js";

export const runtime = "nodejs";

export async function POST(req) {
  const ip = clientIp(req);
  try {
    const parsed = loginSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: "Identifiants invalides." }, { status: 400 });
    const { email, password } = parsed.data;

    // Deux seaux : un par IP (attaque large) et un par compte (bourrage cible).
    for (const key of [`login:ip:${ip}`, `login:user:${email.toLowerCase()}`]) {
      const limit = hit(key, 8, 10 * 60_000);
      if (!limit.ok) {
        return Response.json(
          { error: "Trop de tentatives. Reessaie dans quelques minutes." },
          { status: 429, headers: { "Retry-After": String(limit.retryAfter) } },
        );
      }
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.active || !(await verifyPassword(password, user.passwordHash))) {
      return Response.json({ error: "Email ou mot de passe incorrect." }, { status: 401 });
    }
    reset(`login:user:${email.toLowerCase()}`);
    await createSession(user.id);
    return Response.json({ ok: true, role: user.role });
  } catch (e) {
    return Response.json({ error: e.message }, { status: 500 });
  }
}
