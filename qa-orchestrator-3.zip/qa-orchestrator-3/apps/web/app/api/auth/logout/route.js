import { destroySession } from "@/lib/auth.js";
export const runtime = "nodejs";
export async function POST() {
  await destroySession();
  return Response.json({ ok: true });
}
