import { prisma } from "@/lib/db.js";
import { requireUser, requireAdmin } from "@/lib/auth.js";
import { scenarioSchema } from "@qa/validation";

export const runtime = "nodejs";

// Un testeur ne voit que les scenarios dont le profil lui est attribue.
export async function GET(req) {
  try {
    const user = await requireUser(req);
    const scenarios = await prisma.scenario.findMany({
      where: {
        active: true,
        ...(user.role === "ADMIN"
          ? {}
          : { testProfile: { assignments: { some: { userId: user.id } } } }),
      },
      include: { testProfile: true, region: true },
      orderBy: { name: "asc" },
    });
    return Response.json({ scenarios });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

export async function POST(req) {
  try {
    const user = await requireAdmin(req);
    const parsed = scenarioSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: "Scenario invalide.", details: parsed.error.flatten() }, { status: 400 });
    const d = parsed.data;
    const scenario = await prisma.scenario.create({
      data: {
        name: d.name,
        description: d.description || null,
        testProfileId: d.testProfileId,
        regionId: d.regionId,
        active: d.active,
        restoreProxy: d.restoreProxy,
        createdById: user.id,
      },
      include: { testProfile: true, region: true },
    });
    return Response.json({ scenario });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
