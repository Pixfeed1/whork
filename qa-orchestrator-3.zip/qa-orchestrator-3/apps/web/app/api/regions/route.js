import { prisma } from "@/lib/db.js";
import { requireUser, requireAdmin } from "@/lib/auth.js";
import { regionSchema } from "@qa/validation";

export const runtime = "nodejs";

export async function GET(req) {
  try {
    await requireUser(req);
    const regions = await prisma.region.findMany({ where: { active: true }, orderBy: { label: "asc" } });
    return Response.json({ regions });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

export async function POST(req) {
  try {
    await requireAdmin(req);
    const parsed = regionSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: "Region invalide.", details: parsed.error.flatten() }, { status: 400 });
    const d = parsed.data;
    const region = await prisma.region.create({
      data: { key: d.key, label: d.label, countryCode: d.countryCode.toUpperCase(), city: d.city || null, state: d.state || null, product: d.product },
    });
    return Response.json({ region });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
