import { requireUser } from "@/lib/auth.js";
import { createPairingTicket } from "@/lib/pairing.js";
import { hit } from "@/lib/rate-limit.js";
import { prisma } from "@/lib/db.js";

export const runtime = "nodejs";

// Emet un ticket d'appairage.
//  - un testeur s'en emet un pour lui-meme  -> appareil en attente d'approbation
//  - un admin peut en emettre pour un tiers -> appareil approuve d'office
export async function POST(req) {
  try {
    const user = await requireUser(req);
    const limit = hit(`ticket:${user.id}`, 5, 10 * 60_000);
    if (!limit.ok) {
      return Response.json(
        { error: "Trop de tickets demandes. Reessaie dans quelques minutes." },
        { status: 429, headers: { "Retry-After": String(limit.retryAfter) } },
      );
    }

    const body = await req.json().catch(() => ({}));
    let targetUserId = user.id;
    let autoApprove = false;

    if (body.userId && body.userId !== user.id) {
      if (user.role !== "ADMIN") {
        return Response.json({ error: "Reserve admin." }, { status: 403 });
      }
      const target = await prisma.user.findUnique({ where: { id: body.userId } });
      if (!target) return Response.json({ error: "Utilisateur introuvable." }, { status: 404 });
      targetUserId = target.id;
      autoApprove = body.autoApprove !== false;
    } else if (user.role === "ADMIN") {
      autoApprove = body.autoApprove !== false;
    }

    const ticket = await createPairingTicket({
      userId: targetUserId,
      issuedById: user.id,
      autoApprove,
      portalUrl: process.env.PUBLIC_PORTAL_URL || new URL(req.url).origin,
    });
    return Response.json({ ticket });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
