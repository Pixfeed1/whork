import { prisma } from "@/lib/db.js";
import { requireUser, requireAdmin } from "@/lib/auth.js";
import { getProviders } from "@qa/providers";

export const runtime = "nodejs";

// GET            -> profils de test visibles par l'appelant
//                   (un testeur ne voit QUE ceux qui lui sont attribues)
// GET ?remote=1  -> profils disponibles cote GoLogin (pour import, admin)
export async function GET(req) {
  try {
    const user = await requireUser(req);
    const { searchParams } = new URL(req.url);

    if (searchParams.get("remote") === "1") {
      if (user.role !== "ADMIN") return Response.json({ error: "Reserve admin." }, { status: 403 });
      const { gologin } = getProviders();
      const remote = await gologin.listProfiles(process.env.GOLOGIN_API_TOKEN);
      return Response.json({ remote });
    }

    const profiles = await prisma.testProfile.findMany({
      where: {
        active: true,
        ...(user.role === "ADMIN" ? {} : { assignments: { some: { userId: user.id } } }),
      },
      orderBy: { name: "asc" },
    });
    return Response.json({ profiles });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

// POST -> enregistre un profil GoLogin comme profil de test (admin)
export async function POST(req) {
  try {
    await requireAdmin(req);
    const { gologinProfileId, name, notes } = await req.json();
    if (!gologinProfileId || !name) return Response.json({ error: "gologinProfileId et name requis." }, { status: 400 });
    const profile = await prisma.testProfile.create({
      data: { gologinProfileId, name, notes: notes || null },
    });
    return Response.json({ profile });
  } catch (e) {
    if (e.code === "P2002") return Response.json({ error: "Profil deja enregistre." }, { status: 409 });
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
