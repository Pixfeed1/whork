import { requireLauncher } from "@/lib/auth.js";
import { setJobStatus, requireClaimedJob } from "@/lib/launch-service.js";
import { LaunchStatus } from "@qa/shared";

export const runtime = "nodejs";

// Seul le launcher qui a reclame le job peut faire evoluer son statut, et
// uniquement selon les transitions autorisees (pas de retour en arriere).
export async function POST(req, { params }) {
  try {
    const { user, device } = await requireLauncher(req);
    const { id } = await params;
    const { status, error, exitIp, proxyLabel } = await req.json();

    if (!Object.values(LaunchStatus).includes(status)) {
      return Response.json({ error: "Statut inconnu." }, { status: 400 });
    }
    // Un launcher ne prononce pas de refus : REJECTED appartient aux garde-fous serveur.
    if (status === LaunchStatus.REJECTED || status === LaunchStatus.PENDING) {
      return Response.json({ error: "Statut non emettable par un launcher." }, { status: 400 });
    }

    await requireClaimedJob({
      jobId: id,
      claimToken: req.headers.get("x-claim-token"),
      userId: user.id,
      deviceId: device.id,
    });

    const job = await setJobStatus(id, status, {
      error: error ? String(error).slice(0, 500) : undefined,
      exitIp: exitIp ? String(exitIp).slice(0, 60) : undefined,
      proxyLabel: proxyLabel ? String(proxyLabel).slice(0, 200) : undefined,
    });
    return Response.json({ ok: true, status: job.status });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
