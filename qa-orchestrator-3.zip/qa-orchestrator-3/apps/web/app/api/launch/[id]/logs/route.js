import { prisma } from "@/lib/db.js";
import { requireUser, requireLauncher } from "@/lib/auth.js";
import { addLog, requireClaimedJob, requireReadableJob } from "@/lib/launch-service.js";

export const runtime = "nodejs";

// Lecture : le demandeur du job, le launcher qui l'execute, ou un admin.
export async function GET(req, { params }) {
  try {
    const user = await requireUser(req);
    const { id } = await params;
    await requireReadableJob({ jobId: id, user });
    const logs = await prisma.launchLog.findMany({
      where: { launchJobId: id },
      orderBy: { createdAt: "asc" },
    });
    return Response.json({ logs });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

// Ecriture : reservee au launcher qui detient le jeton de reclamation du job.
export async function POST(req, { params }) {
  try {
    const { user, device } = await requireLauncher(req);
    const { id } = await params;
    const { level, message } = await req.json();
    if (!message) return Response.json({ error: "message requis." }, { status: 400 });

    await requireClaimedJob({
      jobId: id,
      claimToken: req.headers.get("x-claim-token"),
      userId: user.id,
      deviceId: device.id,
    });

    const lvl = ["info", "warn", "error"].includes(level) ? level : "info";
    await addLog(id, lvl, String(message).slice(0, 2000));
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
