import { requireLauncher } from "@/lib/auth.js";
import { heartbeat, requireClaimedJob } from "@/lib/launch-service.js";

export const runtime = "nodejs";

// Prolonge le bail du job. Sans heartbeat, le portail considere le launcher
// perdu et fait echouer le job (voir reapExpiredJobs).
export async function POST(req, { params }) {
  try {
    const { user, device } = await requireLauncher(req);
    const { id } = await params;
    await requireClaimedJob({
      jobId: id,
      claimToken: req.headers.get("x-claim-token"),
      userId: user.id,
      deviceId: device.id,
    });
    const r = await heartbeat(id);
    return Response.json({ ok: true, ...r });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
