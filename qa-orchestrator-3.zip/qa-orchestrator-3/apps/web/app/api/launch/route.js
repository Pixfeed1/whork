import { prisma } from "@/lib/db.js";
import { requireUser } from "@/lib/auth.js";
import { launchRequestSchema } from "@qa/validation";
import { createLaunchJob, reapExpiredJobs } from "@/lib/launch-service.js";

export const runtime = "nodejs";

// Un testeur demande un lancement (scenario + URL cible). Les garde-fous
// sont appliques dans createLaunchJob : rien ne part sans validation.
export async function POST(req) {
  try {
    const user = await requireUser(req);
    const parsed = launchRequestSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: "Requete de lancement invalide." }, { status: 400 });

    const result = await createLaunchJob({
      scenarioId: parsed.data.scenarioId,
      targetUrl: parsed.data.targetUrl,
      userId: user.id,
    });
    if (!result.ok) return Response.json({ error: result.reason }, { status: 422 });
    return Response.json({ ok: true, job: { id: result.job.id, status: result.job.status } });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

// Liste des jobs recents (les siens ; tout pour un admin).
// Selection explicite des colonnes : claimToken et previousProxy (qui contient
// des identifiants proxy) ne doivent JAMAIS sortir de la base.
export async function GET(req) {
  try {
    const user = await requireUser(req);
    await reapExpiredJobs();
    const where = user.role === "ADMIN" ? {} : { requestedById: user.id };
    const jobs = await prisma.launchJob.findMany({
      where,
      orderBy: { createdAt: "desc" },
      take: 30,
      select: {
        id: true,
        status: true,
        targetUrl: true,
        host: true,
        regionKey: true,
        exitIp: true,
        error: true,
        createdAt: true,
        startedAt: true,
        finishedAt: true,
        scenario: { select: { name: true } },
      },
    });
    return Response.json({ jobs });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
