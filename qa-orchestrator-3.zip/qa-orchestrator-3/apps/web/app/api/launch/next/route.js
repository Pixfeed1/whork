import { requireLauncher } from "@/lib/auth.js";
import { claimNextJob } from "@/lib/launch-service.js";

export const runtime = "nodejs";

// Le launcher reclame le prochain job DE SON PROPRE UTILISATEUR.
// POST (et non GET) : l'appel mute l'etat du job.
export async function POST(req) {
  try {
    const { user, device } = await requireLauncher(req);
    const job = await claimNextJob({ userId: user.id, deviceId: device.id });
    if (!job) return Response.json({ job: null });
    return Response.json({ job });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
