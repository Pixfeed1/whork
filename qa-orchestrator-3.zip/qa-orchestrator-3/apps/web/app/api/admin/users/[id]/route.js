import { prisma } from "@/lib/db.js";
import { requireAdmin, hashPassword } from "@/lib/auth.js";
import { userUpdateSchema } from "@qa/validation";

export const runtime = "nodejs";

// Modifie role / activation / mot de passe.
// Desactiver un compte coupe ses sessions web ET launcher immediatement.
export async function PATCH(req, { params }) {
  try {
    const admin = await requireAdmin(req);
    const { id } = await params;
    const parsed = userUpdateSchema.safeParse(await req.json());
    if (!parsed.success) return Response.json({ error: "Requete invalide." }, { status: 400 });
    const d = parsed.data;

    if (id === admin.id && (d.active === false || d.role === "TESTER")) {
      return Response.json({ error: "Impossible de se retirer ses propres droits." }, { status: 400 });
    }

    const data = {};
    if (d.name !== undefined) data.name = d.name || null;
    if (d.role !== undefined) data.role = d.role;
    if (d.active !== undefined) data.active = d.active;
    if (d.password) data.passwordHash = await hashPassword(d.password);

    const user = await prisma.user.update({
      where: { id },
      data,
      select: { id: true, email: true, name: true, role: true, active: true },
    });

    if (d.active === false || d.password) {
      await prisma.session.deleteMany({ where: { userId: id } });
    }
    return Response.json({ user });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
