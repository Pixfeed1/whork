import { prisma } from "@/lib/db.js";
import { requireAdmin, hashPassword } from "@/lib/auth.js";
import { userCreateSchema } from "@qa/validation";

export const runtime = "nodejs";

export async function GET(req) {
  try {
    await requireAdmin(req);
    const users = await prisma.user.findMany({
      orderBy: [{ active: "desc" }, { email: "asc" }],
      select: {
        id: true, email: true, name: true, role: true, active: true, createdAt: true,
        assignments: { include: { testProfile: { select: { id: true, name: true } } } },
        _count: { select: { devices: true, launches: true } },
      },
    });
    return Response.json({ users });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

export async function POST(req) {
  try {
    await requireAdmin(req);
    const parsed = userCreateSchema.safeParse(await req.json());
    if (!parsed.success) {
      return Response.json({ error: "Utilisateur invalide.", details: parsed.error.flatten() }, { status: 400 });
    }
    const d = parsed.data;
    const user = await prisma.user.create({
      data: {
        email: d.email.toLowerCase(),
        name: d.name || null,
        role: d.role,
        passwordHash: await hashPassword(d.password),
      },
      select: { id: true, email: true, name: true, role: true, active: true },
    });
    return Response.json({ user });
  } catch (e) {
    if (e.code === "P2002") return Response.json({ error: "Cet email existe deja." }, { status: 409 });
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
