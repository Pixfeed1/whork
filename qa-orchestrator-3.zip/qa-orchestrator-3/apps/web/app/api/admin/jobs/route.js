import { prisma } from "@/lib/db.js";
import { requireAdmin } from "@/lib/auth.js";
import { reapExpiredJobs } from "@/lib/launch-service.js";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// Journal global des lancements (audit).
export async function GET(req) {
  try {
    await requireAdmin(req);
    await reapExpiredJobs();
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const jobs = await prisma.launchJob.findMany({
      where: status ? { status } : {},
      orderBy: { createdAt: "desc" },
      take: 100,
      include: {
        scenario: { select: { name: true } },
        requestedBy: { select: { email: true } },
        claimedByDevice: { select: { name: true } },
      },
    });
    return Response.json({ jobs });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
