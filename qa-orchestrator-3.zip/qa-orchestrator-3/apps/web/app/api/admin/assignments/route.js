import { prisma } from "@/lib/db.js";
import { requireAdmin } from "@/lib/auth.js";

export const runtime = "nodejs";

// Attribue un profil de test a un utilisateur.
export async function POST(req) {
  try {
    await requireAdmin(req);
    const { userId, testProfileId } = await req.json();
    if (!userId || !testProfileId) {
      return Response.json({ error: "userId et testProfileId requis." }, { status: 400 });
    }
    const assignment = await prisma.profileAssignment.upsert({
      where: { userId_testProfileId: { userId, testProfileId } },
      update: {},
      create: { userId, testProfileId },
      include: { testProfile: { select: { id: true, name: true } } },
    });
    return Response.json({ assignment });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}

// Retire l'attribution.
export async function DELETE(req) {
  try {
    await requireAdmin(req);
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get("userId");
    const testProfileId = searchParams.get("testProfileId");
    if (!userId || !testProfileId) {
      return Response.json({ error: "userId et testProfileId requis." }, { status: 400 });
    }
    await prisma.profileAssignment.deleteMany({ where: { userId, testProfileId } });
    return Response.json({ ok: true });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
