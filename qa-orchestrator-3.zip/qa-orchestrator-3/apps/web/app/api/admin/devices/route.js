import { prisma } from "@/lib/db.js";
import { requireAdmin } from "@/lib/auth.js";

export const runtime = "nodejs";

export async function GET(req) {
  try {
    await requireAdmin(req);
    const devices = await prisma.device.findMany({
      orderBy: [{ status: "asc" }, { createdAt: "desc" }],
      include: { user: { select: { id: true, email: true } } },
    });
    return Response.json({ devices });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
