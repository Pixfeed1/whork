import { prisma } from "@/lib/db.js";
import { requireAdmin } from "@/lib/auth.js";
import { DeviceStatus } from "@qa/shared";

export const runtime = "nodejs";

// Approuve ou revoque un appareil. Une revocation supprime ses sessions :
// le launcher perd l'acces au prochain appel, sans attendre l'expiration.
export async function PATCH(req, { params }) {
  try {
    const admin = await requireAdmin(req);
    const { id } = await params;
    const { status } = await req.json();
    if (![DeviceStatus.APPROVED, DeviceStatus.REVOKED, DeviceStatus.PENDING].includes(status)) {
      return Response.json({ error: "Statut d'appareil inconnu." }, { status: 400 });
    }

    const device = await prisma.device.update({
      where: { id },
      data: {
        status,
        ...(status === DeviceStatus.APPROVED
          ? { approvedById: admin.id, approvedAt: new Date() }
          : { approvedById: null, approvedAt: null }),
      },
      include: { user: { select: { id: true, email: true } } },
    });

    if (status !== DeviceStatus.APPROVED) {
      await prisma.session.deleteMany({ where: { deviceId: id } });
    }
    return Response.json({ device });
  } catch (e) {
    return Response.json({ error: e.message }, { status: e.status || 500 });
  }
}
