import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import UserManager from "./UserManager.jsx";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  await requireAdmin();
  const [users, profiles] = await Promise.all([
    prisma.user.findMany({
      orderBy: [{ active: "desc" }, { email: "asc" }],
      select: {
        id: true, email: true, name: true, role: true, active: true,
        assignments: { select: { testProfile: { select: { id: true, name: true } } } },
        _count: { select: { devices: true, launches: true } },
      },
    }),
    prisma.testProfile.findMany({ where: { active: true }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
  ]);

  return (
    <div className="wrap">
      <p className="eyebrow">Administration · Utilisateurs</p>
      <h1>Comptes et attributions</h1>
      <p className="sub">
        Un testeur ne peut lancer un scénario que si le profil GoLogin correspondant lui est attribué.
        Désactiver un compte coupe ses sessions web et ses launchers immédiatement.
      </p>
      <UserManager
        users={users.map((u) => ({ ...u, profiles: u.assignments.map((a) => a.testProfile) }))}
        profiles={profiles}
      />
    </div>
  );
}
