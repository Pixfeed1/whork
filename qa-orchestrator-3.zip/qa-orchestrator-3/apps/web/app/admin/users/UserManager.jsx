"use client";
import { useState } from "react";

export default function UserManager({ users, profiles }) {
  const [list, setList] = useState(users);
  const [form, setForm] = useState({ email: "", name: "", password: "", role: "TESTER" });
  const [msg, setMsg] = useState(null);
  const [tickets, setTickets] = useState({}); // userId -> ticket emis
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  async function call(url, options) {
    const res = await fetch(url, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Erreur");
    return data;
  }

  async function create() {
    setMsg(null);
    try {
      const { user } = await call("/api/admin/users", { method: "POST", body: JSON.stringify(form) });
      setList((l) => [...l, { ...user, profiles: [], _count: { devices: 0, launches: 0 } }]);
      setForm({ email: "", name: "", password: "", role: "TESTER" });
    } catch (e) {
      setMsg(e.message);
    }
  }

  async function patch(id, body) {
    setMsg(null);
    try {
      const { user } = await call(`/api/admin/users/${id}`, { method: "PATCH", body: JSON.stringify(body) });
      setList((l) => l.map((u) => (u.id === id ? { ...u, ...user } : u)));
    } catch (e) {
      setMsg(e.message);
    }
  }

  // Un ticket emis par un admin pour un tiers approuve son poste d'office :
  // c'est l'admin qui met le collaborateur en service, sans aller-retour.
  async function issueTicket(userId) {
    setMsg(null);
    try {
      const { ticket } = await call("/api/pairing/tickets", {
        method: "POST",
        body: JSON.stringify({ userId, autoApprove: true }),
      });
      setTickets((t) => ({ ...t, [userId]: ticket }));
    } catch (e) {
      setMsg(e.message);
    }
  }

  async function assign(userId, testProfileId) {
    if (!testProfileId) return;
    setMsg(null);
    try {
      const { assignment } = await call("/api/admin/assignments", {
        method: "POST",
        body: JSON.stringify({ userId, testProfileId }),
      });
      setList((l) =>
        l.map((u) =>
          u.id === userId && !u.profiles.some((p) => p.id === testProfileId)
            ? { ...u, profiles: [...u.profiles, assignment.testProfile] }
            : u,
        ),
      );
    } catch (e) {
      setMsg(e.message);
    }
  }

  async function unassign(userId, testProfileId) {
    setMsg(null);
    try {
      await call(`/api/admin/assignments?userId=${userId}&testProfileId=${testProfileId}`, { method: "DELETE" });
      setList((l) =>
        l.map((u) => (u.id === userId ? { ...u, profiles: u.profiles.filter((p) => p.id !== testProfileId) } : u)),
      );
    } catch (e) {
      setMsg(e.message);
    }
  }

  return (
    <>
      <div className="panel" style={{ marginTop: 22 }}>
        <div className="grid two">
          <div>
            <label htmlFor="em">Email</label>
            <input id="em" value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="testeur@exemple.local" />
          </div>
          <div>
            <label htmlFor="nm">Nom</label>
            <input id="nm" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Prénom Nom" />
          </div>
          <div>
            <label htmlFor="pw">Mot de passe (12 caractères minimum)</label>
            <input id="pw" type="password" value={form.password} onChange={(e) => set("password", e.target.value)} />
          </div>
          <div>
            <label htmlFor="rl">Rôle</label>
            <select id="rl" value={form.role} onChange={(e) => set("role", e.target.value)}>
              <option value="TESTER">Testeur</option>
              <option value="ADMIN">Administrateur</option>
            </select>
          </div>
        </div>
        {msg && <div className="err">{msg}</div>}
        <div style={{ marginTop: 14 }}>
          <button className="btn primary" onClick={create} disabled={!form.email || form.password.length < 12}>
            Créer le compte
          </button>
        </div>
      </div>

      <h2 className="sec">Comptes</h2>
      {list.map((u) => (
        <div className="panel" key={u.id} style={{ padding: 16 }}>
          <div className="rowhead">
            <div style={{ minWidth: 0 }}>
              <div className="name" style={{ fontFamily: "var(--display)", fontWeight: 600 }}>
                {u.name || u.email}
              </div>
              <div className="meta" style={{ fontFamily: "var(--mono)", fontSize: 11, color: "var(--muted-2)" }}>
                {u.email} · {u._count?.devices ?? 0} appareil(s) · {u._count?.launches ?? 0} lancement(s)
              </div>
            </div>
            <span className="spacer" />
            <span className={`tag ${u.role === "ADMIN" ? "admin" : ""}`}>{u.role === "ADMIN" ? "admin" : "testeur"}</span>
            <button className="btn ghost sm" onClick={() => patch(u.id, { role: u.role === "ADMIN" ? "TESTER" : "ADMIN" })}>
              {u.role === "ADMIN" ? "Rétrograder" : "Promouvoir"}
            </button>
            <button className={`btn sm ${u.active ? "danger" : "ghost"}`} onClick={() => patch(u.id, { active: !u.active })}>
              {u.active ? "Désactiver" : "Réactiver"}
            </button>
          </div>

          <div style={{ marginTop: 14 }}>
            <label>Appairage du poste</label>
            {tickets[u.id] ? (
              <>
                <div
                  style={{
                    fontFamily: "var(--mono)",
                    fontSize: 20,
                    letterSpacing: "0.14em",
                    color: "var(--accent)",
                    padding: "6px 0",
                    overflowWrap: "anywhere",
                  }}
                >
                  {tickets[u.id].code}
                </div>
                <p className="hint" style={{ margin: 0 }}>
                  À transmettre à {u.email}. Valable jusqu'à{" "}
                  {new Date(tickets[u.id].expiresAt).toLocaleTimeString("fr-FR")}, un seul usage, et le poste
                  sera approuvé d'office.
                </p>
              </>
            ) : (
              <button className="btn ghost sm" onClick={() => issueTicket(u.id)} disabled={!u.active}>
                Générer un code d'appairage
              </button>
            )}
          </div>

          <div style={{ marginTop: 14 }}>
            <label>Profils attribués</label>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
              {u.profiles.length === 0 && <span className="hint" style={{ margin: 0 }}>Aucun : ce compte ne peut lancer aucun test.</span>}
              {u.profiles.map((p) => (
                <span key={p.id} className="badge RUNNING" style={{ display: "inline-flex", gap: 6, alignItems: "center" }}>
                  {p.name}
                  <button
                    className="btn danger sm"
                    style={{ padding: "0 5px", lineHeight: 1.2, fontSize: 11 }}
                    onClick={() => unassign(u.id, p.id)}
                    aria-label={`Retirer ${p.name}`}
                  >
                    ×
                  </button>
                </span>
              ))}
              <select
                defaultValue=""
                onChange={(e) => {
                  assign(u.id, e.target.value);
                  e.target.value = "";
                }}
                style={{ width: "auto", minWidth: 190 }}
              >
                <option value="">Attribuer un profil…</option>
                {profiles
                  .filter((p) => !u.profiles.some((x) => x.id === p.id))
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name}
                    </option>
                  ))}
              </select>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}
