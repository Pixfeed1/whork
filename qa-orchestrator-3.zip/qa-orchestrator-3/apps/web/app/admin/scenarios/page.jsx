import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import ScenarioManager from "./ScenarioManager.jsx";

export const dynamic = "force-dynamic";

export default async function ScenariosPage() {
  await requireAdmin();
  const [scenarios, profiles, regions] = await Promise.all([
    prisma.scenario.findMany({ include: { testProfile: true, region: true }, orderBy: { name: "asc" } }),
    prisma.testProfile.findMany({ where: { active: true }, orderBy: { name: "asc" } }),
    prisma.region.findMany({ where: { active: true }, orderBy: { label: "asc" } }),
  ]);
  return (
    <div className="wrap">
      <p className="eyebrow">Administration</p>
      <h1>Scenarios QA</h1>
      <p className="sub">Un scenario associe un profil de test et une region Oxylabs. Le testeur choisit un scenario et saisit l'URL a ouvrir.</p>
      <ScenarioManager
        scenarios={scenarios.map((s) => ({ id: s.id, name: s.name, profile: s.testProfile.name, region: s.region.label, active: s.active, restoreProxy: s.restoreProxy }))}
        profiles={profiles.map((p) => ({ id: p.id, name: p.name }))}
        regions={regions.map((r) => ({ id: r.id, label: r.label }))}
      />
    </div>
  );
}
