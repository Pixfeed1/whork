"use client";
import { useState } from "react";

export default function ScenarioManager({ scenarios, profiles, regions }) {
  const [list, setList] = useState(scenarios);
  const [form, setForm] = useState({
    name: "", description: "",
    testProfileId: profiles[0]?.id || "", regionId: regions[0]?.id || "",
    restoreProxy: true,
  });
  const [msg, setMsg] = useState(null);
  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const missing = !profiles.length || !regions.length;

  async function create() {
    setMsg(null);
    try {
      const res = await fetch("/api/scenarios", {
        method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur");
      const s = data.scenario;
      setList((l) => [...l, { id: s.id, name: s.name, profile: s.testProfile.name, region: s.region.label, active: s.active, restoreProxy: s.restoreProxy }].sort((a, b) => a.name.localeCompare(b.name)));
      setForm((f) => ({ ...f, name: "", description: "" }));
    } catch (e) { setMsg(e.message); }
  }

  return (
    <>
      <div className="panel">
        {missing ? (
          <div className="notice">Cree d'abord au moins un profil de test et une region.</div>
        ) : (
          <>
            <div className="grid two">
              <div><label>Nom</label><input value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="Checkout depuis l'Allemagne" /></div>
              <div><label>Description</label><input value={form.description} onChange={(e) => set("description", e.target.value)} placeholder="optionnel" /></div>
            </div>
            <div className="grid two" style={{ marginTop: 14 }}>
              <div><label>Profil de test</label><select value={form.testProfileId} onChange={(e) => set("testProfileId", e.target.value)}>{profiles.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}</select></div>
              <div><label>Region</label><select value={form.regionId} onChange={(e) => set("regionId", e.target.value)}>{regions.map((r) => <option key={r.id} value={r.id}>{r.label}</option>)}</select></div>
            </div>
            <div style={{ marginTop: 14, display: "flex", alignItems: "flex-start", gap: 10 }}>
              <input
                id="rp"
                type="checkbox"
                checked={form.restoreProxy}
                onChange={(e) => set("restoreProxy", e.target.checked)}
                style={{ width: "auto", marginTop: 2 }}
              />
              <label htmlFor="rp" style={{ margin: 0 }}>
                Restaurer le proxy d'origine du profil apres le test
                <span className="hint" style={{ marginTop: 2 }}>
                  Le proxy deja configure sur le profil GoLogin est relu avant le test, puis remis a la fermeture.
                  Decoche uniquement si le profil est dedie a la QA et n'a pas de proxy a preserver.
                </span>
              </label>
            </div>
            {msg && <div className="err">{msg}</div>}
            <div style={{ marginTop: 14 }}><button className="btn primary" onClick={create} disabled={!form.name}>Creer le scenario</button></div>
          </>
        )}
      </div>
      <h2 className="sec">{list.length} scenario(s)</h2>
      {list.map((s) => (
        <div className="row" key={s.id}>
          <div>
            <div className="name">{s.name}</div>
            <div className="meta">{s.profile} · {s.region}{s.restoreProxy === false ? " · proxy non restaure" : ""}</div>
          </div>
          <span className="spacer" />
          <span className={`badge ${s.active ? "DONE" : "FAILED"}`}>{s.active ? "actif" : "inactif"}</span>
        </div>
      ))}
    </>
  );
}
