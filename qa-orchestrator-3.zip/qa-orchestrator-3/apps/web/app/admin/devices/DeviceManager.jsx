"use client";
import { useState } from "react";

const LABEL = { APPROVED: "approuvé", PENDING: "en attente", REVOKED: "révoqué" };
const BADGE = { APPROVED: "DONE", PENDING: "PENDING", REVOKED: "FAILED" };

export default function DeviceManager({ devices }) {
  const [list, setList] = useState(devices);
  const [msg, setMsg] = useState(null);

  async function setStatus(id, status) {
    setMsg(null);
    try {
      const res = await fetch(`/api/admin/devices/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur");
      setList((l) => l.map((d) => (d.id === id ? { ...d, status } : d)));
    } catch (e) {
      setMsg(e.message);
    }
  }

  if (!list.length) {
    return (
      <div className="notice" style={{ marginTop: 22 }}>
        Aucun poste appairé. Chaque collaborateur génère son code depuis « Mon launcher ».
      </div>
    );
  }

  return (
    <div style={{ marginTop: 22 }}>
      {msg && <div className="err">{msg}</div>}
      {list.map((d) => (
        <div className="row" key={d.id}>
          <div>
            <div className="name">{d.name}</div>
            <div className="meta">
              {d.email} · {d.platform || "plateforme inconnue"} · launcher {d.appVersion || "?"}
              {d.lastSeenAt ? ` · vu ${new Date(d.lastSeenAt).toLocaleString("fr-FR")}` : " · jamais connecté"}
            </div>
          </div>
          <span className="spacer" />
          <span className={`badge ${BADGE[d.status]}`}>{LABEL[d.status]}</span>
          {d.status !== "APPROVED" && (
            <button className="btn ghost sm" onClick={() => setStatus(d.id, "APPROVED")}>
              Approuver
            </button>
          )}
          {d.status !== "REVOKED" && (
            <button className="btn danger sm" onClick={() => setStatus(d.id, "REVOKED")}>
              Révoquer
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
