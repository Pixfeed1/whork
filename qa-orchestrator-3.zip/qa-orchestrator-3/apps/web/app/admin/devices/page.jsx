import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import DeviceManager from "./DeviceManager.jsx";

export const dynamic = "force-dynamic";

export default async function AdminDevicesPage() {
  await requireAdmin();
  const devices = await prisma.device.findMany({
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    include: { user: { select: { email: true } } },
  });

  return (
    <div className="wrap">
      <p className="eyebrow">Administration · Appareils</p>
      <h1>Postes autorisés</h1>
      <p className="sub">
        Un launcher ne récupère aucun job tant que son poste n'est pas approuvé. Révoquer un appareil coupe
        sa session au prochain appel, sans attendre l'expiration du jeton.
      </p>
      <DeviceManager
        devices={devices.map((d) => ({
          id: d.id,
          name: d.name,
          platform: d.platform,
          appVersion: d.appVersion,
          status: d.status,
          email: d.user.email,
          lastSeenAt: d.lastSeenAt?.toISOString() || null,
          createdAt: d.createdAt.toISOString(),
        }))}
      />
    </div>
  );
}
