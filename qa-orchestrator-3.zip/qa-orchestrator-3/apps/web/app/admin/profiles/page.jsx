import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import ProfileManager from "./ProfileManager.jsx";

export const dynamic = "force-dynamic";

export default async function ProfilesPage() {
  await requireAdmin();
  const profiles = await prisma.testProfile.findMany({ orderBy: { name: "asc" } });
  return (
    <div className="wrap">
      <p className="eyebrow">Administration</p>
      <h1>Profils de test</h1>
      <p className="sub">Enregistre les profils GoLogin existants a utiliser en QA. « Importer depuis GoLogin » liste tes profils via l'API (ou des profils fictifs en mode mock).</p>
      <ProfileManager initial={profiles.map((p) => ({ id: p.id, gologinProfileId: p.gologinProfileId, name: p.name, notes: p.notes }))} />
    </div>
  );
}
