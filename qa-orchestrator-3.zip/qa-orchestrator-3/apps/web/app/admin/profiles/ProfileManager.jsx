"use client";
import { useState } from "react";

export default function ProfileManager({ initial }) {
  const [profiles, setProfiles] = useState(initial);
  const [remote, setRemote] = useState([]);
  const [msg, setMsg] = useState(null);
  const [loading, setLoading] = useState(false);

  async function loadRemote() {
    setLoading(true); setMsg(null);
    try {
      const res = await fetch("/api/profiles?remote=1");
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur");
      setRemote(data.remote || []);
    } catch (e) { setMsg(e.message); } finally { setLoading(false); }
  }

  async function importProfile(p) {
    setMsg(null);
    try {
      const res = await fetch("/api/profiles", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ gologinProfileId: p.id, name: p.name }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erreur");
      setProfiles((list) => [...list, data.profile].sort((a, b) => a.name.localeCompare(b.name)));
    } catch (e) { setMsg(e.message); }
  }

  const known = new Set(profiles.map((p) => p.gologinProfileId));

  return (
    <>
      <div className="panel">
        <button className="btn ghost sm" onClick={loadRemote} disabled={loading}>{loading ? "Chargement…" : "Importer depuis GoLogin"}</button>
        {msg && <div className="err">{msg}</div>}
        {remote.length > 0 && (
          <div style={{ marginTop: 14 }}>
            {remote.map((p) => (
              <div className="row" key={p.id}>
                <div>
                  <div className="name">{p.name}</div>
                  <div className="meta">{p.os} · {p.id}</div>
                </div>
                <span className="spacer" />
                {known.has(p.id)
                  ? <span className="badge DONE">deja importe</span>
                  : <button className="btn primary sm" onClick={() => importProfile(p)}>Importer</button>}
              </div>
            ))}
          </div>
        )}
      </div>
      <h2 className="sec">{profiles.length} profil(s) de test</h2>
      {profiles.map((p) => (
        <div className="row" key={p.id}>
          <div>
            <div className="name">{p.name}</div>
            <div className="meta">{p.gologinProfileId}</div>
          </div>
        </div>
      ))}
    </>
  );
}
