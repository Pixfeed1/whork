import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import { DeviceStatus } from "@qa/shared";

export const dynamic = "force-dynamic";

export default async function AdminHome() {
  await requireAdmin();
  const [profiles, regions, scenarios, users, pendingDevices, jobs] = await Promise.all([
    prisma.testProfile.count(),
    prisma.region.count(),
    prisma.scenario.count(),
    prisma.user.count({ where: { active: true } }),
    prisma.device.count({ where: { status: DeviceStatus.PENDING } }),
    prisma.launchJob.count(),
  ]);

  const cards = [
    { href: "/admin/scenarios", label: "Scénarios", n: scenarios, desc: "Profil de test + région Oxylabs." },
    { href: "/admin/profiles", label: "Profils de test", n: profiles, desc: "Profils GoLogin retenus pour la QA." },
    { href: "/admin/users", label: "Utilisateurs", n: users, desc: "Comptes actifs et attribution des profils." },
    { href: "/admin/devices", label: "Appareils", n: pendingDevices, desc: pendingDevices ? "En attente d'approbation." : "Aucun poste en attente." },
    { href: "/admin/jobs", label: "Lancements", n: jobs, desc: "Journal d'audit complet." },
  ];

  return (
    <div className="wrap">
      <p className="eyebrow">Administration</p>
      <h1>Console d'administration</h1>
      <p className="sub">Gère les briques de test. Régions disponibles : {regions}.</p>
      <div className="grid three" style={{ marginTop: 22 }}>
        {cards.map((c) => (
          <a key={c.href} href={c.href} className="panel" style={{ display: "block" }}>
            <div style={{ fontFamily: "var(--mono)", fontSize: 30, color: "var(--accent)" }}>{c.n}</div>
            <div style={{ fontFamily: "var(--display)", fontWeight: 600, marginTop: 4 }}>{c.label}</div>
            <div className="hint">{c.desc}</div>
          </a>
        ))}
      </div>
    </div>
  );
}
