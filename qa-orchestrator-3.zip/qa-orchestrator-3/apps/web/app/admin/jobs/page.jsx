import { requireAdmin } from "@/lib/auth.js";
import { prisma } from "@/lib/db.js";
import { reapExpiredJobs } from "@/lib/launch-service.js";

export const dynamic = "force-dynamic";

export default async function AdminJobsPage() {
  await requireAdmin();
  await reapExpiredJobs();

  const jobs = await prisma.launchJob.findMany({
    orderBy: { createdAt: "desc" },
    take: 60,
    select: {
      id: true, status: true, targetUrl: true, regionKey: true, exitIp: true, error: true,
      createdAt: true, finishedAt: true,
      scenario: { select: { name: true } },
      requestedBy: { select: { email: true } },
      claimedByDevice: { select: { name: true } },
    },
  });

  return (
    <div className="wrap">
      <p className="eyebrow">Administration · Journal</p>
      <h1>Tous les lancements</h1>
      <p className="sub">
        Trace d'audit : qui a lancé quoi, depuis quel poste, vers quelle URL, et ce que le garde-fou a refusé.
      </p>

      <div style={{ marginTop: 22 }}>
        {jobs.length === 0 && (
          <div className="row">
            <span className="meta">Aucun lancement enregistré.</span>
          </div>
        )}
        {jobs.map((j) => (
          <div className="row" key={j.id}>
            <div style={{ minWidth: 0 }}>
              <div className="name">{j.scenario?.name || "—"}</div>
              <div className="meta">
                {j.requestedBy.email} · {j.targetUrl} · {j.regionKey}
                {j.claimedByDevice ? ` · poste ${j.claimedByDevice.name}` : ""}
                {j.exitIp ? ` · sortie ${j.exitIp}` : ""}
                {j.error ? ` · ${j.error}` : ""}
              </div>
              <div className="meta">{new Date(j.createdAt).toLocaleString("fr-FR")}</div>
            </div>
            <span className="spacer" />
            <span className={`badge ${j.status}`}>{j.status}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
