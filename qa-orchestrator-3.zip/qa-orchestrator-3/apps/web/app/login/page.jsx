"use client";
import { useState } from "react";

export default function LoginPage() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Echec");
      window.location.href = data.role === "ADMIN" ? "/admin" : "/tests";
    } catch (e2) { setErr(e2.message); } finally { setBusy(false); }
  }

  return (
    <div className="wrap">
      <div className="panel card-login">
        <p className="eyebrow">Portail interne</p>
        <h1 style={{ fontSize: 24 }}>QA Orchestrator</h1>
        <p className="sub" style={{ marginBottom: 18 }}>Connecte-toi pour gerer et lancer tes tests.</p>
        <form onSubmit={submit}>
          <label htmlFor="e">Email</label>
          <input id="e" type="email" value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="username" required />
          <div style={{ height: 12 }} />
          <label htmlFor="p">Mot de passe</label>
          <input id="p" type="password" value={password} onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" required />
          {err && <div className="err">{err}</div>}
          <div style={{ height: 16 }} />
          <button className="btn primary" style={{ width: "100%" }} disabled={busy}>{busy ? "Connexion…" : "Se connecter"}</button>
        </form>
      </div>
    </div>
  );
}
