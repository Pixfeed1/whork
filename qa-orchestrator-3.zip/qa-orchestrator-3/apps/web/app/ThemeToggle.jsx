"use client";
import { useEffect, useState } from "react";
import { THEME_KEY } from "./theme.js";

const NEXT = { auto: "light", light: "dark", dark: "auto" };
const LABEL = { auto: "auto", light: "clair", dark: "sombre" };
const TITLE = {
  auto: "Thème automatique : sombre de 19 h à 7 h. Cliquer pour forcer le clair.",
  light: "Thème clair forcé. Cliquer pour forcer le sombre.",
  dark: "Thème sombre forcé. Cliquer pour revenir à l'automatique.",
};

export default function ThemeToggle() {
  // Rien n'est rendu avant le montage : le serveur ne connaît pas l'heure du
  // poste, l'afficher côté serveur produirait un écart d'hydratation.
  const [mode, setMode] = useState(null);

  useEffect(() => {
    setMode(document.documentElement.dataset.themeMode || "auto");
  }, []);

  function cycle() {
    const next = NEXT[mode] || "light";
    try {
      if (next === "auto") localStorage.removeItem(THEME_KEY);
      else localStorage.setItem(THEME_KEY, next);
    } catch {
      // Navigation privée sans stockage : le thème tiendra le temps de la page.
    }
    setMode(next);
    window.__qaApplyTheme?.();
  }

  if (!mode) return <span className="theme-toggle" style={{ visibility: "hidden" }} aria-hidden="true">auto</span>;

  return (
    <button className="theme-toggle" onClick={cycle} title={TITLE[mode]} aria-label={TITLE[mode]}>
      {LABEL[mode]}
    </button>
  );
}
