// Seed initial : admin, regions du catalogue, un profil + un scenario d'exemple.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { REGION_CATALOG } from "@qa/shared";

const prisma = new PrismaClient();

async function main() {
  const email = (process.env.SEED_ADMIN_EMAIL || "admin@exemple.local").toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD || "change-me";
  if (password.length < 12) {
    console.warn("⚠  SEED_ADMIN_PASSWORD fait moins de 12 caracteres : change-le avant toute mise en service.");
  }
  const passwordHash = await bcrypt.hash(password, 10);

  const admin = await prisma.user.upsert({
    where: { email },
    update: {},
    create: { email, name: "Admin QA", passwordHash, role: "ADMIN" },
  });
  console.log("Admin:", admin.email);

  for (const r of REGION_CATALOG) {
    await prisma.region.upsert({
      where: { key: r.key },
      update: { label: r.label, countryCode: r.countryCode, city: r.city ?? null, state: r.state ?? null },
      create: {
        key: r.key,
        label: r.label,
        countryCode: r.countryCode,
        city: r.city ?? null,
        state: r.state ?? null,
        product: "residential",
      },
    });
  }
  console.log(`${REGION_CATALOG.length} regions seedees.`);

  // Profil de test d'exemple (id mock, remplacer par un vrai id GoLogin).
  const profile = await prisma.testProfile.upsert({
    where: { gologinProfileId: "mock-profile-fr" },
    update: {},
    create: { gologinProfileId: "mock-profile-fr", name: "QA · Desktop FR", notes: "Profil d'exemple." },
  });

  // Sans attribution, meme l'admin ne verrait pas le profil dans les listes
  // filtrees. On attribue explicitement le profil d'exemple a l'admin.
  await prisma.profileAssignment.upsert({
    where: { userId_testProfileId: { userId: admin.id, testProfileId: profile.id } },
    update: {},
    create: { userId: admin.id, testProfileId: profile.id },
  });

  const fr = await prisma.region.findUnique({ where: { key: "fr" } });

  // Scenario d'exemple pret a lancer en mode mock.
  const existing = await prisma.scenario.findFirst({ where: { name: "Exemple — Accueil FR" } });
  if (!existing) {
    await prisma.scenario.create({
      data: {
        name: "Exemple — Accueil FR",
        description: "Verifie l'accueil depuis la France (mode mock par defaut).",
        testProfileId: profile.id,
        regionId: fr.id,
        restoreProxy: true,
        createdById: admin.id,
      },
    });
    console.log("Scenario d'exemple cree.");
  }
}

main()
  .then(() => prisma.$disconnect())
  .catch(async (e) => {
    console.error(e);
    await prisma.$disconnect();
    process.exit(1);
  });
