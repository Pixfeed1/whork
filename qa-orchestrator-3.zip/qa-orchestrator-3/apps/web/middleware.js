import { NextResponse } from "next/server";
import { SESSION_COOKIE } from "./lib/constants.js";

// Garde legere : redirige vers /login si pas de cookie de session.
// L'autorisation reelle (role, validite) est verifiee cote serveur
// dans chaque page/route.
export function middleware(req) {
  const { pathname } = req.nextUrl;
  const isProtected =
    pathname === "/" ||
    pathname.startsWith("/admin") ||
    pathname.startsWith("/tests") ||
    pathname.startsWith("/launcher");
  if (!isProtected) return NextResponse.next();

  const hasCookie = req.cookies.has(SESSION_COOKIE);
  if (!hasCookie) {
    const url = req.nextUrl.clone();
    url.pathname = "/login";
    return NextResponse.redirect(url);
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/", "/admin/:path*", "/tests/:path*", "/launcher/:path*"],
};
