/** @type {import('next').NextConfig} */
const nextConfig = {
  // Packages du monorepo transpiles par Next.
  transpilePackages: ["@qa/shared", "@qa/validation", "@qa/providers"],
  // Le web ne lance PAS Orbita ; gologin reste externe par securite.
  serverExternalPackages: ["gologin", "puppeteer-core", "@prisma/client", "bcryptjs"],
};
export default nextConfig;
