# Packager et distribuer le launcher

Le launcher n'est pas un projet de dev qu'on lance avec `electron .` : c'est un
logiciel qu'on installe sur le poste d'un collaborateur. Ce document couvre la
chaine complete : bundle, installeur, signature, protocole, mise a jour.

## 1. Chaine de build

```
src/*.js  --esbuild-->  dist/main.cjs + preload.cjs + index.html + renderer.js
dist/     --electron-builder-->  release/*.exe | *.dmg | *.AppImage
```

L'etape esbuild (`apps/launcher/build.mjs`) n'est pas cosmetique. Les paquets
`@qa/shared` et `@qa/providers` sont des workspaces npm hoistes a la racine du
monorepo : electron-builder ne sait pas les embarquer depuis un sous-dossier.
On les inline donc dans le bundle. Ne restent externes que `gologin` et
`electron-updater`, installes normalement comme dependances de l'app.

```bash
npm run launcher:build       # bundle seul
npm run launcher:dist        # bundle + installeur pour la plateforme courante
npm run launcher:dist:win    # NSIS (.exe)
npm run launcher:dist:mac    # DMG x64 + arm64
npm run launcher:dist:linux  # AppImage + deb
```

Les artefacts atterrissent dans `apps/launcher/release/`.

## 2. Signature

**Sans signature, l'installeur fonctionne mais chaque collaborateur voit un
avertissement** (SmartScreen sur Windows, Gatekeeper sur macOS) — et surtout
electron-updater ne peut plus verifier l'origine des mises a jour. C'est la
seule etape qui demande d'acheter quelque chose.

### Windows

Il faut un certificat de signature de code (OV ou EV) au format `.pfx`.

```bash
export CSC_LINK=/chemin/vers/certificat.pfx   # ou une URL https
export CSC_KEY_PASSWORD='mot-de-passe-du-pfx'
npm run launcher:dist:win
```

L'horodatage est deja configure (`rfc3161TimeStampServer`) : sans lui, les
binaires deviennent invalides a l'expiration du certificat.

Un certificat OV declenche encore SmartScreen tant que la reputation n'est pas
etablie. Un certificat EV (sur token materiel) l'evite immediatement.

### macOS

Il faut un compte Apple Developer (99 $/an) et un certificat
« Developer ID Application ».

```bash
export APPLE_ID='compte@exemple.fr'
export APPLE_APP_SPECIFIC_PASSWORD='xxxx-xxxx-xxxx-xxxx'
export APPLE_TEAM_ID='XXXXXXXXXX'
npm run launcher:dist:mac
```

`notarize: true` est deja actif dans `electron-builder.yml`. Le fichier
`build/entitlements.mac.plist` autorise le JIT et le chargement de librairies
non signees : Orbita (Chromium) est lance comme processus enfant et ne
demarrerait pas sous runtime durci sans ces autorisations.

### Linux

Pas de signature requise. L'AppImage et le `.deb` s'installent tels quels.

## 3. Protocole personnalise

Le portail affiche un lien `qa-launcher://pair?code=...&portal=https://...`.
Un clic ouvre l'application installee et transmet le ticket : aucun
copier-coller, aucun mot de passe saisi dans le launcher.

L'enregistrement est fait a trois endroits, et les trois sont necessaires :

| Endroit                          | Role                                        |
|----------------------------------|---------------------------------------------|
| `electron-builder.yml` `protocols` | declare le schema a l'installeur           |
| `build/installer.nsh`            | ecrit les cles de registre Windows          |
| `src/protocol.js`                 | `setAsDefaultProtocolClient` + parsing      |

Le parsing n'accepte que `http`/`https` comme portail : un lien forge ne peut
pas pointer le launcher vers un `file://` ou un schema exotique.

En developpement (`npm run launcher:dev`), le protocole est enregistre vers
`process.execPath` + le script : le clic marche aussi, sans installeur.

## 4. Mise a jour automatique et checksums

electron-builder genere un `latest.yml` contenant le **sha512 de chaque
artefact**. electron-updater telecharge, recalcule l'empreinte, et refuse
l'installation si elle ne correspond pas. Sur Windows et macOS, il verifie en
plus la signature du binaire. La verification est integree : il n'y a pas de
checksum a gerer a la main, mais elle ne vaut que si le flux est servi en
**HTTPS** et que les binaires sont **signes**.

Mise en place :

1. Publier le contenu de `release/` (installeurs + `latest.yml`) dans un
   dossier servi en HTTPS, par ex. `https://qa.exemple.local/launcher/`.
2. Poste de build : `export QA_UPDATE_FEED=https://qa.exemple.local/launcher/`
   avant `npm run launcher:dist`.
3. Portail : `LAUNCHER_UPDATE_FEED_URL=https://qa.exemple.local/launcher/`.

Le launcher interroge `GET /api/launcher/version` au demarrage et configure son
flux a partir de cette reponse. Le serveur de mise a jour n'est donc pas fige
dans le binaire.

## 5. Version minimale

`LAUNCHER_MIN_VERSION` cote portail est la seule source de verite. Chaque appel
du launcher porte un en-tete `X-Launcher-Version` ; en dessous du minimum,
l'API repond **426 Upgrade Required** et le launcher cesse de reclamer des
jobs, avec un bandeau explicite dans l'interface.

Le but : pouvoir couper une version buguee ou trouee sans toucher aux postes.
Relever la variable, redemarrer le portail, c'est fait.

```
LAUNCHER_MIN_VERSION="1.2.0"
LAUNCHER_LATEST_VERSION="1.3.0"
```

## 6. Mise en service d'un poste

1. Le collaborateur installe l'app (lien de `LAUNCHER_DOWNLOAD_URL`).
2. Il ouvre le portail, page **Mon launcher**, et clique
   **Générer un code d'appairage**.
3. Il clique **Ouvrir le launcher et appairer** — l'app s'ouvre appairee.
4. Un admin approuve le poste dans **Admin → Appareils**.
   (Si l'admin a lui-meme emis le ticket, le poste est approuve d'office.)
5. Le launcher peut reclamer les jobs de ce collaborateur, et d'aucun autre.

Le jeton est chiffre au repos via `safeStorage` (DPAPI / Keychain /
libsecret). Sans coffre-fort systeme disponible, le launcher **refuse d'ecrire
le jeton en clair** et redemande l'appairage au demarrage suivant.

## 7. Revoquer

| Situation                | Action                                              |
|--------------------------|-----------------------------------------------------|
| Poste perdu ou vole      | Admin → Appareils → **Révoquer**                    |
| Depart d'un collaborateur| Admin → Utilisateurs → **Désactiver**               |
| Jeton suspect            | Révoquer l'appareil : le reappairage est obligatoire|

Une revocation supprime les sessions de l'appareil : l'acces tombe au prochain
appel, sans attendre l'expiration du jeton (30 jours).
