# Deploiement

## 1. Base de donnees

`docker compose up -d db` lance PostgreSQL 16 (port 5432, volume persistant).
Ou utilise ta propre instance et adapte `DATABASE_URL`.

## 2. Migrations Prisma

La 1re fois, genere la migration initiale (cree les tables) :

```bash
npm run db:migrate:dev -w @qa/web    # prisma migrate dev --name init
```

En production / conteneur, applique les migrations existantes :

```bash
npm run db:migrate -w @qa/web        # prisma migrate deploy
```

> Le `CMD` du conteneur web execute `prisma migrate deploy` au demarrage : une
> migration doit donc exister dans `apps/web/prisma/migrations` (commite-la).

## 3. Seed

```bash
npm run db:seed
```

Cree l'admin (`SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD`), les regions du
catalogue, un profil et un scenario d'exemple.

## 4. Portail

- Dev : `npm run web:dev`.
- Docker : `docker compose up --build web` (build depuis la racine du monorepo,
  cf. `apps/web/Dockerfile`).

Variables du portail : `DATABASE_URL`, `SESSION_SECRET`, `PROVIDER_MODE`,
et en mode live `GOLOGIN_API_TOKEN`, `OXYLABS_*`.

## 5. Launcher (poste testeur)

Le launcher n'est pas dockerise (il ouvre un navigateur local). Sur chaque poste :

```bash
QA_PORTAL_URL=https://qa.mondomaine.tld \
PROVIDER_MODE=live \
GOLOGIN_API_TOKEN=xxx \
OXYLABS_USERNAME=xxx OXYLABS_PASSWORD=xxx OXYLABS_PRODUCT=residential \
npm run launcher:dev
```

Pour distribuer un binaire, ajouter `electron-builder` (non inclus ici).

## 6. Mode live : checklist

- Token GoLogin : https://app.gologin.com/personalArea/TokenApi
- Identifiants proxy Oxylabs (le "proxy user", pas le login dashboard).
- Verifier `OXYLABS_PRODUCT` : `residential` (cc-) vs `shared_dc_isp` (country-).
- Tester une region : la table `LaunchJob.exitIp` doit refleter le pays vise.

## 7. Mise en service des launchers

Le portail seul ne suffit pas : chaque collaborateur installe le launcher sur
son poste, puis l'appaire. Aucun mot de passe n'est saisi dans le launcher.

1. Construire et publier l'installeur — voir [PACKAGING.md](PACKAGING.md).
2. Renseigner cote portail :

   ```
   PUBLIC_PORTAL_URL="https://qa.exemple.local"   # fabrique le lien d'appairage
   LAUNCHER_MIN_VERSION="1.0.0"                   # plancher impose aux clients
   LAUNCHER_LATEST_VERSION="1.0.0"
   LAUNCHER_UPDATE_FEED_URL="https://qa.exemple.local/launcher/"
   LAUNCHER_DOWNLOAD_URL="https://qa.exemple.local/launcher/"
   ```

3. Le collaborateur ouvre **Mon launcher**, genere un code, clique
   **Ouvrir le launcher et appairer**.
4. Un admin approuve le poste dans **Admin → Appareils**.
5. Un admin attribue au compte les profils GoLogin qu'il a le droit de piloter
   dans **Admin → Utilisateurs**. Sans attribution, aucun scenario n'est
   visible ni lancable — c'est volontaire.

## 8. Ce que le portail garantit

| Garantie                         | Mecanisme                                          |
|----------------------------------|----------------------------------------------------|
| URL analysable, en http/https    | Validation a la creation ET a la reclamation       |
| Un launcher ne vole pas un job   | Reclamation filtree par utilisateur, `claimToken`  |
| Pas de double reclamation        | `SELECT … FOR UPDATE SKIP LOCKED` en une requete   |
| Pas de job fantome               | Bail de 90 s + heartbeat 30 s + reaper             |
| Un poste inconnu n'a pas d'acces | Ticket a usage unique + approbation admin          |
| Une fuite de base ne donne rien  | Jetons stockes en SHA-256, jamais en clair         |
| Un profil emprunte est rendu     | Sauvegarde et restauration du proxy d'origine      |
| Une version trouee est coupee    | `LAUNCHER_MIN_VERSION` + en-tete de version        |

## 9. Points a traiter avant la vraie production

- **Migration Prisma** : le schema a change (appareils, tickets, attributions,
  baux). Generer et commiter la migration : `npm run db:migrate:dev -w @qa/web`.
- **Limiteur de debit** : `apps/web/lib/rate-limit.js` est en memoire, donc par
  instance. Derriere plusieurs replicas, le remplacer par Redis (meme interface :
  `hit`, `reset`).
- **Next.js 15.1.6** porte une vulnerabilite connue (CVE-2025-66478) : passer a
  une version corrigee avant exposition.
- **Endpoint proxy GoLogin** : `PATCH /browser/{id}/proxy` est conforme a la doc
  officielle, mais reste a valider en conditions reelles avec un profil de demo
  avant la premiere campagne.
- **Aucun filtrage de domaine** : l'outil ouvre l'URL demandee. Le journal
  (`Admin → Lancements`) est la seule trace de ce qui a ete ouvert — le
  conserver et le consulter fait partie du dispositif.
