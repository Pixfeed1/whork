# Architecture

## Pourquoi deux applications

Le portail web est la source de verite (comptes, scenarios, attributions,
appareils, logs). Mais
il ne peut pas lancer Orbita : un serveur — a fortiori un conteneur Docker — n'a
ni interface graphique ni acces au poste du testeur. GoLogin s'ouvre **en local**.

D'ou la separation :

- **apps/web** : authentifie, stocke, expose une file de jobs, journalise.
- **apps/launcher** : tourne sur le poste du testeur, appaire une fois pour
  toutes, reclame **ses** jobs, execute GoLogin + proxy, remonte le resultat.

## Flux d'un lancement

```
Testeur (navigateur)                Portail (Next.js)                 Launcher (Electron, local)
      |                                    |                                   |
      |  POST /api/launch {scenario,url}   |                                   |
      |----------------------------------->|                                   |
      |            createLaunchJob()        |                                   |
      |   [URL analysable + http/https]     |                                   |
      |   [profil attribue au demandeur]    |                                   |
      |   job PENDING (ou REJECTED trace)   |                                   |
      |<-----------------------------------|                                   |
      |                                    |  POST /api/launch/next (Bearer)    |
      |                                    |<----------------------------------|
      |                                    |  claimNextJob(userId, deviceId)    |
      |                                    |  UPDATE .. FOR UPDATE SKIP LOCKED  |
      |                                    |  filtre requestedById = userId     |
      |                                    |----------------------------------> job + claimToken
      |                                    |                                   | buildProxyForRegion (Oxylabs)
      |                                    |                                   | getProfileProxy -> memorise
      |                                    |                                   | setProfileProxy (GoLogin REST)
      |                                    |                                   | launchProfile (SDK) -> Orbita
      |                                    |   POST /status {RUNNING,exitIp}    | ouvre l'URL demandee
      |                                    |<----------------------------------|
      |                                    |   POST /heartbeat  (toutes les 30s)|
      |                                    |<----------------------------------|
      |                                    |   POST /logs ...                   |
      |                                    |<----------------------------------|
      |   (le portail affiche statut+logs) |   POST /status {DONE} a la ferm.   |
      |                                    |<----------------------------------| restaure le proxy d'origine
```

Toute ecriture du launcher porte `X-Claim-Token` : le secret remis une seule
fois a la reclamation. Sans bail renouvele (90 s), le job est passe en FAILED.

## Ou vivent les controles

Il n'y a **pas** de restriction de domaine : l'outil ouvre l'URL demandee. Les
controles restants portent sur *qui* fait *quoi*, pas sur *ou*.

| Controle                          | Emplacement                                  |
|-----------------------------------|----------------------------------------------|
| URL analysable + http/https       | `packages/validation/src/url.js`             |
| Profil attribue au demandeur      | `apps/web/lib/launch-service.js` (create)    |
| Reclamation atomique + par usager | `apps/web/lib/launch-service.js` (claim)     |
| Propriete d'un job en cours       | `claimToken` + `requireClaimedJob()`         |
| Appareil approuve, version a jour | `apps/web/lib/auth.js` (`requireLauncher`)   |
| Bail / job fantome                | `heartbeat()` + `reapExpiredJobs()`          |
| Journalisation                    | tables `LaunchJob` / `LaunchLog`             |

## Providers et mode mock

`getProviders(env)` lit `PROVIDER_MODE`. En `mock`, GoLogin/Oxylabs sont
remplaces par des implementations sans reseau (`packages/providers/src/mock.js`),
ce qui permet de developper et tester le flux complet sans aucun compte externe.

## Endpoints externes utilises (verifies)

- GoLogin REST : `GET https://api.gologin.com/browser/v2`,
  `PATCH https://api.gologin.com/browser/{id}/proxy`.
- GoLogin SDK : package npm `gologin` (`GologinApi.launch/stop`).
- Oxylabs : entree `pr.oxylabs.io:7777`, ciblage geo **dans le username**
  (`-cc-XX`, `-cc-XX-city-...`, `-st-us_...`, `-sessid-...`), verif IP sur
  `https://ip.oxylabs.io/location`. Oxylabs n'expose pas d'API pour "pousser"
  une region : tout se joue dans les identifiants.
