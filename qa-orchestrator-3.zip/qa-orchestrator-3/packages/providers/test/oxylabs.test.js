import { test } from "node:test";
import assert from "node:assert/strict";
import { buildOxylabsUsername, buildProxyForRegion } from "../src/oxylabs.js";

const account = { host: "pr.oxylabs.io", port: "7777", username: "acme", password: "sekret", product: "residential" };

test("pays seul -> cc-XX", () => {
  const u = buildOxylabsUsername("acme", { countryCode: "FR" });
  assert.equal(u, "customer-acme-cc-FR");
});

test("pays + ville -> cc-XX-city-slug", () => {
  const u = buildOxylabsUsername("acme", { countryCode: "US", city: "Los Angeles" });
  assert.equal(u, "customer-acme-cc-US-city-los_angeles");
});

test("etat US -> st-us_xxx", () => {
  const u = buildOxylabsUsername("acme", { countryCode: "US", state: "us_california" });
  assert.equal(u, "customer-acme-st-us_california");
});

test("DC/ISP partage -> country- au lieu de cc-", () => {
  const u = buildOxylabsUsername("acme", { countryCode: "DE", product: "shared_dc_isp" });
  assert.equal(u, "customer-acme-country-DE");
});

test("session stable -> sessid + sesstime", () => {
  const u = buildOxylabsUsername("acme", { countryCode: "FR" }, { sessionId: "qa123", sessionMinutes: 60 });
  assert.equal(u, "customer-acme-cc-FR-sessid-qa123-sesstime-60");
});

test("buildProxyForRegion ne fuit jamais le mot de passe dans le label", () => {
  const p = buildProxyForRegion(account, { countryCode: "FR" });
  assert.equal(p.host, "pr.oxylabs.io");
  assert.equal(p.username, "customer-acme-cc-FR");
  assert.equal(p.password, "sekret");
  assert.ok(!p.label.includes("sekret"));
});
