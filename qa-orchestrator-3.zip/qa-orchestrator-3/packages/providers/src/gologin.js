// Provider GoLogin — endpoints REST officiels + SDK officiel.
//
// Endpoints verifies sur la doc officielle (gologin.com/docs/api-reference) :
//   - GET   /browser/v2            liste des profils          ("Get all profiles")
//   - GET   /browser/{id}          profil par id              ("Get profile by id")
//   - PATCH /browser/{id}/proxy    proxy custom sur un profil ("Update profile proxy")
//     body : { mode, host, port, username, password }
//
// SDK : package npm "gologin" (GologinApi) pour lancer/arreter Orbita en local.
// ATTENTION : le README du depot montre `const browser = await GL.launch(...)`
// alors que le quickstart officiel montre `const { browser } = await GL.launch(...)`.
// Le SDK v2 renvoie bien un OBJET. On normalise les deux formes ci-dessous
// plutot que de parier sur l'une des deux.
//
// Ce qui N'EST PAS possible officiellement : forcer Orbita a n'ouvrir qu'une
// seule URL et bloquer toute autre navigation via l'API. On ouvre l'URL
// demandee ; ensuite la navigation appartient a la personne devant l'ecran.

const BASE = "https://api.gologin.com";

function headers(token) {
  return { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
}

async function fail(res, what) {
  const t = await res.text().catch(() => "");
  throw new Error(`GoLogin: ${what} (HTTP ${res.status}). ${t.slice(0, 200)}`);
}

export async function listProfiles(token) {
  const res = await fetch(`${BASE}/browser/v2`, { headers: headers(token), cache: "no-store" });
  if (!res.ok) await fail(res, "liste des profils refusee");
  const data = await res.json();
  const raw = Array.isArray(data) ? data : data.profiles || data.data || [];
  return raw.map((p) => ({
    id: p.id || p._id,
    name: p.name || "Sans nom",
    os: p.os || (p.navigator && p.navigator.platform) || "",
  }));
}

/** Profil complet (utilise pour relire le proxy en place avant de l'ecraser). */
export async function getProfile(token, profileId) {
  const res = await fetch(`${BASE}/browser/${profileId}`, { headers: headers(token), cache: "no-store" });
  if (!res.ok) await fail(res, "lecture du profil refusee");
  return res.json();
}

/**
 * Lit le proxy actuellement configure sur un profil, sous une forme
 * directement rejouable par setProfileProxy(). null si le profil n'en a pas.
 */
export async function getProfileProxy(token, profileId) {
  const profile = await getProfile(token, profileId);
  const p = profile?.proxy;
  if (!p || !p.mode || p.mode === "none") return null;
  return {
    mode: p.mode,
    host: p.host || "",
    port: Number(p.port) || 0,
    username: p.username || "",
    password: p.password || "",
  };
}

export async function setProfileProxy(token, profileId, proxy) {
  const body = {
    mode: proxy.mode || "http",
    host: proxy.host,
    port: Number(proxy.port),
    username: proxy.username || "",
    password: proxy.password || "",
  };
  const res = await fetch(`${BASE}/browser/${profileId}/proxy`, {
    method: "PATCH",
    headers: headers(token),
    body: JSON.stringify(body),
  });
  if (!res.ok) await fail(res, "application du proxy refusee");
  return true;
}

/** Remet le profil sans proxy (mode "none"), pour restaurer un profil qui n'en avait pas. */
export async function clearProfileProxy(token, profileId) {
  const res = await fetch(`${BASE}/browser/${profileId}/proxy`, {
    method: "PATCH",
    headers: headers(token),
    body: JSON.stringify({ mode: "none", host: "", port: 0, username: "", password: "" }),
  });
  if (!res.ok) await fail(res, "retrait du proxy refuse");
  return true;
}

/**
 * Lance un profil GoLogin en local (Orbita) et ouvre UNIQUEMENT l'URL fournie.
 * Necessite le package "gologin" (dependance du launcher, pas du web).
 * @returns {Promise<{ gl:any, browser:any, exitIp:string|null }>}
 */
export async function launchProfile(token, profileId, { startUrl } = {}) {
  const mod = await import("gologin");
  const GologinApi = mod.GologinApi || mod.default?.GologinApi || mod.default;
  if (typeof GologinApi !== "function") {
    throw new Error("SDK gologin introuvable ou incompatible : GologinApi n'est pas exporte.");
  }
  const gl = GologinApi({ token });

  // Le SDK renvoie { browser } (quickstart officiel) ; certaines versions du
  // README montrent le browser directement. On accepte les deux.
  const launched = await gl.launch({ profileId });
  const browser = launched?.browser ?? launched;
  if (!browser || typeof browser.newPage !== "function") {
    throw new Error("GoLogin: launch() n'a pas renvoye d'instance navigateur exploitable.");
  }

  let exitIp = null;
  try {
    const page = await browser.newPage();
    // On lit l'IP de sortie pour tracer la region reellement obtenue.
    await page.goto("https://api.ipify.org?format=json", {
      waitUntil: "domcontentloaded",
      timeout: 30000,
    });
    const body = await page.evaluate(() => document.body.innerText);
    exitIp = JSON.parse(body).ip || null;
    // Puis on ouvre l'URL autorisee (et rien d'autre — aucune action automatisee).
    if (startUrl) await page.goto(startUrl, { waitUntil: "domcontentloaded", timeout: 45000 });
  } catch {
    // Non bloquant : le profil reste ouvert meme si la verif IP echoue.
  }

  return { gl, browser, exitIp };
}

export async function stopProfile(gl, browser) {
  try { if (browser) await browser.close(); } catch {}
  try { if (gl?.stop) await gl.stop(); } catch {}
  try { if (gl?.exit) await gl.exit(); } catch {}
}
