// Fabrique de providers pilotee par l'environnement.
// PROVIDER_MODE=mock -> aucun appel externe. Sinon -> providers reels.

import * as live from "./gologin.js";
import * as oxylabs from "./oxylabs.js";
import * as mock from "./mock.js";

export { buildProxyForRegion, buildOxylabsUsername, OXYLABS_CHECK_URL } from "./oxylabs.js";

export function getProviders(env = process.env) {
  const mode = (env.PROVIDER_MODE || "mock").toLowerCase();
  const isMock = mode === "mock";

  const gologin = isMock ? mock : live;

  return {
    mode,
    isMock,
    gologin,
    oxylabs,
    // Compte Oxylabs assemble depuis l'env (utilise en mode live).
    oxylabsAccount: {
      host: env.OXYLABS_HOST || "pr.oxylabs.io",
      port: env.OXYLABS_PORT || "7777",
      username: env.OXYLABS_USERNAME || "",
      password: env.OXYLABS_PASSWORD || "",
      product: env.OXYLABS_PRODUCT || "residential",
    },
  };
}
