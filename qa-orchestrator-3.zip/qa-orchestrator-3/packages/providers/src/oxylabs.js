// Provider Oxylabs — construit les identifiants proxy a partir d'une region.
// AUCUN endpoint invente : la syntaxe de ciblage geo suit la doc officielle
// (https://developers.oxylabs.io) :
//   - pays      : customer-USER-cc-XX            (residentiel/mobile)
//   - ville     : customer-USER-cc-XX-city-nom   (la ville exige cc)
//   - etat US   : customer-USER-st-us_xxx
//   - session   : ...-sessid-xxxx[-sesstime-N]   (IP stable, N minutes, max 1440)
//   - DC/ISP partage : cc- devient country-
//
// Oxylabs ne fournit PAS d'API pour "pousser une region" : le ciblage se fait
// entierement dans le username. Ce provider ne fait donc que composer une
// chaine d'identifiants ; c'est GoLogin qui portera ce proxy.

import { OxylabsProduct } from "@qa/shared";

function citySlug(city) {
  return String(city).trim().toLowerCase().replace(/\s+/g, "_");
}

/**
 * @typedef {Object} Region
 * @property {string} countryCode  ISO alpha-2
 * @property {string} [city]
 * @property {string} [state]      ex: "us_california"
 * @property {string} [product]    OxylabsProduct.*
 */

/**
 * Compose le username Oxylabs pour une region donnee.
 * @param {string} baseUser        identifiant proxy Oxylabs (sans prefixe)
 * @param {Region} region
 * @param {{ sessionId?: string, sessionMinutes?: number }} [opts]
 */
export function buildOxylabsUsername(baseUser, region, opts = {}) {
  const product = region.product || OxylabsProduct.RESIDENTIAL;
  const cc = String(region.countryCode || "").toUpperCase();
  const parts = [`customer-${baseUser}`];

  // Choix du flag pays selon le produit (doc officielle).
  const ccFlag = product === OxylabsProduct.SHARED_DC_ISP ? "country" : "cc";

  // Un seul niveau geo prioritaire : ville > etat > pays, pour eviter les
  // combinaisons ignorees (Oxylabs ne garde qu'un parametre de localisation).
  if (cc && region.city) {
    parts.push(`${ccFlag}-${cc}`, `city-${citySlug(region.city)}`);
  } else if (region.state) {
    parts.push(`st-${region.state}`);
  } else if (cc) {
    parts.push(`${ccFlag}-${cc}`);
  }

  // Session stable (reproductibilite QA).
  if (opts.sessionId) {
    parts.push(`sessid-${opts.sessionId}`);
    if (opts.sessionMinutes) parts.push(`sesstime-${Math.min(1440, opts.sessionMinutes)}`);
  }

  return parts.join("-");
}

/**
 * Construit l'objet proxy consommable par GoLogin (PATCH /browser/{id}/proxy).
 * @param {{host:string, port:number, username:string, password:string, product?:string}} account
 * @param {Region} region
 * @param {{ sessionId?: string, sessionMinutes?: number, mode?: string }} [opts]
 */
export function buildProxyForRegion(account, region, opts = {}) {
  const regionWithProduct = { ...region, product: region.product || account.product };
  const username = buildOxylabsUsername(account.username, regionWithProduct, opts);
  return {
    mode: opts.mode || "http", // Oxylabs residentiel supporte http/https/socks5
    host: account.host,
    port: Number(account.port),
    username,
    password: account.password,
    // Label lisible pour les logs (jamais le mot de passe).
    label: `${account.host}:${account.port} · ${username}`,
  };
}

// URL officielle de verification de localisation/IP.
export const OXYLABS_CHECK_URL = "https://ip.oxylabs.io/location";
