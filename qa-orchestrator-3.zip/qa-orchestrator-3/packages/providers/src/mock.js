// Provider MOCK — permet de developper et tester TOUT le flux sans GoLogin
// ni Oxylabs (ni reseau, ni navigateur). Active quand PROVIDER_MODE=mock.

let counter = 0;

const FAKE_PROFILES = [
  { id: "mock-profile-fr", name: "QA · Desktop FR", os: "win" },
  { id: "mock-profile-de", name: "QA · Desktop DE", os: "win" },
  { id: "mock-profile-mob", name: "QA · Mobile US", os: "android" },
];

// Proxy "deja en place" sur les profils mock, pour exercer la restauration.
const FAKE_PROXIES = new Map([
  ["mock-profile-fr", { mode: "http", host: "proxy.interne.local", port: 8080, username: "qa", password: "secret" }],
]);

export async function listProfiles() {
  return FAKE_PROFILES;
}

export async function getProfile(_token, profileId) {
  const p = FAKE_PROFILES.find((x) => x.id === profileId) || { id: profileId, name: "Inconnu" };
  return { ...p, proxy: FAKE_PROXIES.get(profileId) || { mode: "none" } };
}

export async function getProfileProxy(_token, profileId) {
  return FAKE_PROXIES.get(profileId) || null;
}

export async function setProfileProxy(_token, profileId, proxy) {
  FAKE_PROXIES.set(profileId, { ...proxy });
  return true;
}

export async function clearProfileProxy(_token, profileId) {
  FAKE_PROXIES.delete(profileId);
  return true;
}

export async function launchProfile(_token, profileId, { startUrl } = {}) {
  counter += 1;
  // IP factice deterministe, juste pour tracer un "resultat".
  const exitIp = `203.0.113.${(counter % 250) + 1}`; // plage de doc (RFC 5737)
  return {
    gl: { __mock: true },
    browser: {
      __mock: true,
      profileId,
      openedUrl: startUrl || null,
      async newPage() { return { async goto() {}, async evaluate() { return "{}"; } }; },
      async close() {},
    },
    exitIp,
  };
}

export async function stopProfile() {
  return true;
}
