// Catalogue de regions de test "prêtes a l'emploi".
// Chaque region decrit un ciblage geo Oxylabs cote pays (+ ville optionnelle).
// L'admin peut aussi creer ses propres regions en base ; ceci sert de
// catalogue de depart et de seed.
//
// Codes pays au format ISO 3166-1 alpha-2 (exige par Oxylabs).

export const REGION_CATALOG = [
  { key: "fr", label: "France", countryCode: "FR" },
  { key: "fr-paris", label: "France — Paris", countryCode: "FR", city: "paris" },
  { key: "de", label: "Allemagne", countryCode: "DE" },
  { key: "gb", label: "Royaume-Uni", countryCode: "GB" },
  { key: "es", label: "Espagne", countryCode: "ES" },
  { key: "it", label: "Italie", countryCode: "IT" },
  { key: "us", label: "Etats-Unis", countryCode: "US" },
  { key: "us-ca", label: "Etats-Unis — Californie", countryCode: "US", state: "us_california" },
  { key: "ca", label: "Canada", countryCode: "CA" },
  { key: "jp", label: "Japon", countryCode: "JP" },
  { key: "au", label: "Australie", countryCode: "AU" },
  { key: "br", label: "Bresil", countryCode: "BR" },
];

export function findRegion(key) {
  return REGION_CATALOG.find((r) => r.key === key) || null;
}
