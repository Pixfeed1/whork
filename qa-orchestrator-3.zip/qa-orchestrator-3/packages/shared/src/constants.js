// Enums partages entre le web, le launcher et les providers.
// (JS pur + JSDoc : pas de build, importable partout.)

/** Statuts d'un job de lancement. */
export const LaunchStatus = Object.freeze({
  PENDING: "PENDING", // cree par un testeur, en attente de SON launcher
  RUNNING: "RUNNING", // launcher a reclame le job et ouvert le profil
  DONE: "DONE", // session terminee proprement
  FAILED: "FAILED", // erreur au lancement, ou bail expire
  REJECTED: "REJECTED", // refuse avant execution (URL invalide, scenario inactif, profil non attribue)
});

/** Transitions autorisees. Un job termine ne repart jamais en arriere. */
export const ALLOWED_TRANSITIONS = Object.freeze({
  PENDING: ["RUNNING", "REJECTED", "FAILED"],
  RUNNING: ["RUNNING", "DONE", "FAILED"],
  DONE: [],
  FAILED: [],
  REJECTED: [],
});

export function isTerminal(status) {
  return status === LaunchStatus.DONE || status === LaunchStatus.FAILED || status === LaunchStatus.REJECTED;
}

export function canTransition(from, to) {
  return (ALLOWED_TRANSITIONS[from] || []).includes(to);
}

/** Roles utilisateur. */
export const Role = Object.freeze({
  ADMIN: "ADMIN",
  TESTER: "TESTER",
});

/** Nature d'une session : cookie navigateur ou token d'appareil. */
export const SessionKind = Object.freeze({
  WEB: "WEB",
  LAUNCHER: "LAUNCHER",
});

/** Etat d'un appareil enregistre. */
export const DeviceStatus = Object.freeze({
  PENDING: "PENDING",
  APPROVED: "APPROVED",
  REVOKED: "REVOKED",
});

/** Niveaux de log technique. */
export const LogLevel = Object.freeze({
  INFO: "info",
  WARN: "warn",
  ERROR: "error",
});

/** Types de produit Oxylabs (conditionnent la syntaxe de ciblage geo). */
export const OxylabsProduct = Object.freeze({
  RESIDENTIAL: "residential", // username: customer-USER-cc-XX
  SHARED_DC_ISP: "shared_dc_isp", // username: customer-USER-country-XX
  DEDICATED: "dedicated", // ciblage par port dedie (voir dashboard)
});

// --- Duree de vie ---------------------------------------------------------

/** Bail d'un job reclame. Sans heartbeat, le job est libere/echoue apres ce delai. */
export const JOB_LEASE_MS = 90_000;
/** Intervalle de heartbeat cote launcher (doit rester < JOB_LEASE_MS / 2). */
export const JOB_HEARTBEAT_MS = 30_000;
/** Duree de validite d'un ticket d'appairage a usage unique. */
export const PAIRING_TICKET_TTL_MS = 10 * 60_000;
/** Duree d'une session launcher (renouvelee a chaque appairage). */
export const LAUNCHER_SESSION_MS = 30 * 24 * 60 * 60_000;
/** Duree d'une session web. */
export const WEB_SESSION_MS = 7 * 24 * 60 * 60_000;

/** Schema du protocole personnalise (appairage en un clic). */
export const APP_PROTOCOL = "qa-launcher";

// --- Comparaison de versions (semver simplifie x.y.z) ----------------------

/**
 * Compare deux versions "x.y.z". Renvoie -1, 0 ou 1.
 * Tolere les suffixes (-beta.1) qui sont ignores.
 */
export function compareVersions(a, b) {
  const parse = (v) =>
    String(v || "0")
      .split("-")[0]
      .split(".")
      .map((n) => Number.parseInt(n, 10) || 0);
  const [x, y] = [parse(a), parse(b)];
  for (let i = 0; i < 3; i += 1) {
    const d = (x[i] || 0) - (y[i] || 0);
    if (d !== 0) return d > 0 ? 1 : -1;
  }
  return 0;
}

/** La version du launcher satisfait-elle le minimum exige par le portail ? */
export function versionSatisfies(current, minimum) {
  return compareVersions(current, minimum) >= 0;
}
