import { z } from "zod";
import { OxylabsProduct, Role } from "@qa/shared";

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

// Politique de mot de passe : longueur avant tout (NIST SP 800-63B).
export const passwordSchema = z.string().min(12, "12 caracteres minimum").max(200);

export const userCreateSchema = z.object({
  email: z.string().email(),
  name: z.string().max(120).optional().default(""),
  password: passwordSchema,
  role: z.nativeEnum(Role).optional().default(Role.TESTER),
});

export const userUpdateSchema = z.object({
  name: z.string().max(120).optional(),
  role: z.nativeEnum(Role).optional(),
  active: z.boolean().optional(),
  password: passwordSchema.optional(),
});

export const regionSchema = z.object({
  key: z.string().min(2).max(40).regex(/^[a-z0-9-]+$/, "clé en minuscules, chiffres et tirets"),
  label: z.string().min(1).max(80),
  countryCode: z.string().length(2).regex(/^[A-Za-z]{2}$/, "code pays ISO alpha-2"),
  city: z.string().max(60).optional().nullable(),
  state: z.string().max(60).optional().nullable(),
  product: z.nativeEnum(OxylabsProduct).optional().default(OxylabsProduct.RESIDENTIAL),
});

export const scenarioSchema = z.object({
  name: z.string().min(1).max(120),
  description: z.string().max(1000).optional().default(""),
  testProfileId: z.string().min(1),
  regionId: z.string().min(1),
  active: z.boolean().optional().default(true),
  // Relire le proxy en place sur le profil et le remettre apres le test.
  restoreProxy: z.boolean().optional().default(true),
});

// Le testeur choisit un scenario (profil + region) et l'URL a ouvrir.
export const launchRequestSchema = z.object({
  scenarioId: z.string().min(1),
  targetUrl: z.string().url(),
});

// Appairage d'un launcher.
export const pairRequestSchema = z.object({
  code: z.string().min(8).max(40),
  deviceKey: z.string().min(16).max(200),
  deviceName: z.string().max(120).optional().default(""),
  platform: z.string().max(60).optional().default(""),
  appVersion: z.string().max(40).optional().default(""),
});
