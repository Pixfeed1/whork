// Analyse de l'URL cible.
//
// Aucune restriction de domaine : l'outil ouvre l'URL demandee, point.
// Ne subsistent que deux controles, qui ne limitent pas l'usage :
//   - l'URL doit etre analysable (sinon Orbita ne saurait pas quoi ouvrir) ;
//   - le protocole doit etre http/https (un `javascript:` ou un `file:` passe
//     en startUrl est un bug, pas un cas d'usage).
// L'hote est extrait pour la journalisation.

/**
 * Normalise un hote : minuscules, sans point final, sans port.
 * @param {string} host
 */
export function normalizeHost(host) {
  return String(host || "").toLowerCase().replace(/\.$/, "").split(":")[0].trim();
}

/**
 * Valide une URL cible.
 * @param {string} url
 * @returns {{ ok: boolean, host: string|null, reason?: string }}
 */
export function validateTargetUrl(url) {
  let parsed;
  try {
    parsed = new URL(String(url));
  } catch {
    return { ok: false, host: null, reason: "URL invalide." };
  }
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    return { ok: false, host: null, reason: "Seuls http et https sont autorises." };
  }
  const host = normalizeHost(parsed.hostname);
  if (!host) return { ok: false, host: null, reason: "Hote absent." };

  return { ok: true, host };
}
