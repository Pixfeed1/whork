import { test } from "node:test";
import assert from "node:assert/strict";
import { validateTargetUrl, normalizeHost } from "../src/url.js";

test("normalizeHost : minuscules, sans port ni point final", () => {
  assert.equal(normalizeHost("Example.COM"), "example.com");
  assert.equal(normalizeHost("staging.pixfeed.net:8080"), "staging.pixfeed.net");
  assert.equal(normalizeHost("example.com."), "example.com");
  assert.equal(normalizeHost(""), "");
});

test("n'importe quel domaine passe", () => {
  for (const u of ["https://google.com/", "http://localhost:3000/checkout", "https://staging.pixfeed.net/a?b=c"]) {
    assert.equal(validateTargetUrl(u).ok, true, u);
  }
});

test("l'hote est extrait pour le journal", () => {
  const r = validateTargetUrl("https://staging.pixfeed.net/checkout");
  assert.equal(r.ok, true);
  assert.equal(r.host, "staging.pixfeed.net");
});

test("URL inanalysable -> refus", () => {
  const r = validateTargetUrl("pas une url");
  assert.equal(r.ok, false);
  assert.match(r.reason, /invalide/);
});

test("protocole non http(s) -> refus", () => {
  for (const u of ["ftp://pixfeed.net/", "file:///etc/passwd", "javascript:alert(1)"]) {
    assert.equal(validateTargetUrl(u).ok, false, u);
  }
});
