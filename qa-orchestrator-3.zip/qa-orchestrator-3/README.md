# QA Orchestrator

Orchestrateur QA **interne** pour tester **ses propres sites et applications** :
profils GoLogin de test (environnements de navigation stables) + regions Oxylabs
(pour simuler differentes zones geographiques et verifier redirections,
geolocalisation, contenus localises et performances).

Ce n'est **pas** un outil de scraping ni d'automatisation : l'outil ouvre une
URL dans un profil, et n'effectue **aucune action** sur la page ouverte.

## Perimetre

Le perimetre est une **regle d'usage, pas une contrainte technique** : l'outil
ouvre l'URL demandee, sans restriction de domaine. Ce qui reste vrai dans le
code :

- Oxylabs sert uniquement de fournisseur de proxy pour simuler des regions.
- Aucune action n'est automatisee sur les sites ouverts : on ouvre, point.
- Session proxy stable (`sessid`) pour la **reproductibilite**, pas pour de la
  rotation d'evasion.
- Tout ce qui est ouvert est **journalise** : qui, quand, quelle URL, quel
  profil, quelle region, quelle IP de sortie.

Profils, comptes de test et applications testes sont censes t'appartenir ou
etre explicitement autorises. Le portail ne le verifie pas : il le trace.

## Monorepo

```
apps/
  web/         Portail Next.js (auth, admin, scenarios, appareils, logs)  + Docker
  launcher/    Launcher local Electron (ouvre le profil GoLogin en local)
packages/
  shared/      Enums + catalogue de regions
  validation/  Validation d'URL + schemas zod (teste)
  providers/   GoLogin (REST+SDK), Oxylabs (proxy), mock  (teste)
```

## Architecture en deux temps

Un portail (surtout dockerise) ne peut pas ouvrir Orbita sur le poste du
testeur. Le portail est donc la **source de verite** (comptes, scenarios,
attributions, logs) et le **launcher local** execute :

1. l'admin cree un scenario (profil GoLogin + region) ;
2. l'admin attribue le profil aux testeurs qui ont le droit de le piloter ;
3. le testeur se connecte, saisit une URL et clique « Lancer le test » ;
4. le serveur cree un job `PENDING` et journalise la cible ;
5. le launcher **de ce testeur**, sur un poste approuve, reclame le job de
   facon atomique et recoit un `claimToken` a usage unique ;
6. il memorise le proxy en place sur le profil, puis applique celui de la region ;
7. Orbita ouvre **uniquement l'URL autorisee** ;
8. un heartbeat toutes les 30 s prolonge le bail ; sans lui le job echoue ;
9. a la fermeture, le proxy d'origine est restaure ;
10. le portail conserve statut + logs + IP de sortie.

Detail dans `docs/ARCHITECTURE.md`.

## Demarrage rapide (mode mock, zero compte externe)

```bash
npm install

# base Postgres (via Docker) OU une base locale
docker compose up -d db

cp .env.example .env         # PROVIDER_MODE=mock par defaut
# renseigne DATABASE_URL, SESSION_SECRET, SEED_ADMIN_*

npm run db:migrate:dev -w @qa/web   # cree le schema (genere la 1re migration)
npm run db:seed                     # admin + regions + scenario d'exemple
npm run web:dev                     # http://localhost:3000
```

Puis, pour le poste de test :

```bash
npm run launcher:dev                # bundle + ouvre le launcher
```

Le launcher demarre **non appaire**. Va sur http://localhost:3000/launcher,
genere un code, clique « Ouvrir le launcher et appairer ». Un ticket admin
approuve le poste d'office ; un ticket que se genere un testeur laisse
l'appareil en attente jusqu'a validation dans **Admin → Appareils**.

## Themes et responsive

Deux themes, bascule **automatique sur l'heure locale du poste** : sombre de
19 h a 7 h, clair le reste du temps, re-evalue chaque minute (la fenetre laissee
ouverte bascule toute seule). Un script bloquant dans `<head>` pose le theme
avant le premier rendu : pas de flash blanc au chargement.

La barre du portail expose une bascule a trois etats — `auto` (defaut), `clair`,
`sombre` — memorisee dans `localStorage`. Un automatisme sans echappatoire est
hostile : quelqu'un dans une piece sombre a 10 h doit pouvoir forcer. Le
launcher, lui, suit l'heure sans reglage : sa page tourne sur `file://`, ou
`localStorage` n'est pas fiable.

Les bornes vivent dans `apps/web/app/theme.js` (`DARK_FROM` / `DARK_TO`) et
`apps/launcher/src/theme.js`.

Toute couleur passe par un token ; les deux palettes tiennent **WCAG AA
(4.5:1)** sur chaque couple texte/fond, fond de page inclus.

| Rupture | Effet                                                        |
|---------|--------------------------------------------------------------|
| 940 px  | la grille perd sa marge, les paddings se resserrent           |
| 760 px  | trois colonnes -> deux ; l'email disparait de la barre        |
| 560 px  | une colonne ; lignes empilees ; boutons pleine largeur        |

## Modele d'acces

| Qui                | Peut                                                            |
|--------------------|-----------------------------------------------------------------|
| Admin              | tout : comptes, profils, scenarios, appareils, journal           |
| Testeur            | lancer les scenarios dont le profil lui est **attribue**         |
| Launcher appaire   | reclamer les jobs de **son seul** utilisateur, sur un poste approuve |
| Poste non approuve | rien                                                             |

Deux natures de session, non interchangeables : le cookie web n'ouvre aucun
job, le jeton de launcher n'ouvre pas l'interface. Les deux sont stockes en
SHA-256 : une copie de la base ne donne aucune session utilisable.

Puis, dans un autre terminal, le launcher :

```bash
QA_PORTAL_URL=http://localhost:3000 npm run launcher:dev
```

En mode `mock`, tout le flux fonctionne **sans GoLogin ni Oxylabs** : le
launcher simule l'ouverture et remonte un resultat + des logs.

## Passer en mode live

Dans `.env` : `PROVIDER_MODE=live`, `GOLOGIN_API_TOKEN`, `OXYLABS_USERNAME`,
`OXYLABS_PASSWORD`, `OXYLABS_PRODUCT`. Voir `docs/DEPLOYMENT.md`.

## Ce que le code controle encore

Il n'y a **aucune restriction de domaine** : c'est un choix assume, l'outil
ouvre ce qu'on lui demande. Ce qui subsiste :

- **URL analysable, en http/https** — un `javascript:` ou un `file:` passe en
  `startUrl` est un bug, pas un cas d'usage (`packages/validation/src/url.js`).
- **Attribution profil ↔ utilisateur** : un testeur ne pilote que les profils
  qui lui ont ete attribues.
- **Appareils approuves** : un poste inconnu ne recupere aucun job.
- **Cloisonnement des jobs** : un launcher ne reclame que les jobs de son
  propre utilisateur, et ne peut ecrire que sur ceux qu'il detient.
- **Journalisation integrale** (`LaunchJob` / `LaunchLog`) : c'est desormais la
  seule trace de ce qui a ete ouvert. Elle n'empeche rien, elle rend compte.

## Limitation documentee

Il n'existe pas d'API officielle GoLogin pour **verrouiller la navigation
d'Orbita a une seule URL**. Le launcher ouvre l'URL demandee et n'intercepte pas
le trafic dans la page (ce serait de l'automatisation, hors perimetre). Une fois
Orbita ouvert, la navigation appartient a la personne devant l'ecran. Voir
`packages/providers/src/gologin.js`.

## Tests

```bash
npm test            # tous les packages
```

Couvre la validation d'URL et la construction des identifiants Oxylabs.
